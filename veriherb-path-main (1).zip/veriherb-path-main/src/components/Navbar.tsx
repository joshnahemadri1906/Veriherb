import { Link, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Leaf, LayoutDashboard, MapPin, FlaskConical, Cog, QrCode, Menu, X, BookOpen, Activity, Bell, LogIn, Upload } from "lucide-react";
import { useState } from "react";

const navItems = [
  { path: "/", label: "Home", icon: Leaf },
  { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { path: "/collection", label: "Collection", icon: MapPin },
  { path: "/quality", label: "Quality Tests", icon: FlaskConical },
  { path: "/processing", label: "Processing", icon: Cog },
  { path: "/consumer", label: "Consumer Portal", icon: QrCode },
  { path: "/herbs", label: "Herb Directory", icon: BookOpen },
  { path: "/health", label: "Health Guide", icon: Activity },
  { path: "/alerts", label: "Alerts", icon: Bell },
  { path: "/farmer-upload", label: "Farmer Upload", icon: Upload },
];

export default function Navbar() {
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const isHome = location.pathname === "/";
  const isLogin = location.pathname === "/login";

  if (isLogin) return null;

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-colors duration-300 ${isHome ? "bg-forest/80 backdrop-blur-md" : "bg-background/90 backdrop-blur-md border-b border-border"}`}>
      <div className="container mx-auto flex items-center justify-between h-16 px-4">
        <Link to="/" className="flex items-center gap-2">
          <Leaf className={`w-7 h-7 ${isHome ? "text-turmeric" : "text-primary"}`} />
          <span className={`font-display font-bold text-xl ${isHome ? "text-cream" : "text-foreground"}`}>VanaSetu</span>
        </Link>

        {/* Desktop */}
        <div className="hidden lg:flex items-center gap-1">
          {navItems.map((item) => {
            const active = location.pathname === item.path;
            return (
              <Link key={item.path} to={item.path}
                className={`relative px-2.5 py-2 rounded-md text-xs font-medium transition-colors ${
                  isHome
                    ? active ? "text-turmeric" : "text-cream/70 hover:text-cream"
                    : active ? "text-primary" : "text-muted-foreground hover:text-foreground"
                }`}>
                <item.icon className="w-3.5 h-3.5 inline mr-1 -mt-0.5" />
                {item.label}
                {active && (
                  <motion.div layoutId="nav-underline" className={`absolute bottom-0 left-2 right-2 h-0.5 rounded-full ${isHome ? "bg-turmeric" : "bg-primary"}`} />
                )}
              </Link>
            );
          })}
          <Link to="/login" className={`ml-2 px-3 py-1.5 rounded-md text-xs font-medium gradient-leaf text-primary-foreground`}>
            <LogIn className="w-3.5 h-3.5 inline mr-1 -mt-0.5" /> Login
          </Link>
        </div>

        {/* Mobile toggle */}
        <button className="lg:hidden" onClick={() => setOpen(!open)}>
          {open ? <X className={isHome ? "text-cream" : "text-foreground"} /> : <Menu className={isHome ? "text-cream" : "text-foreground"} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
          className={`lg:hidden border-t ${isHome ? "bg-forest border-cream/10" : "bg-background border-border"}`}>
          {navItems.map((item) => (
            <Link key={item.path} to={item.path} onClick={() => setOpen(false)}
              className={`flex items-center gap-3 px-6 py-3 text-sm ${
                location.pathname === item.path
                  ? isHome ? "text-turmeric" : "text-primary"
                  : isHome ? "text-cream/70" : "text-muted-foreground"
              }`}>
              <item.icon className="w-4 h-4" />
              {item.label}
            </Link>
          ))}
          <Link to="/login" onClick={() => setOpen(false)}
            className={`flex items-center gap-3 px-6 py-3 text-sm ${isHome ? "text-turmeric" : "text-primary"}`}>
            <LogIn className="w-4 h-4" /> Login / Sign Up
          </Link>
        </motion.div>
      )}
    </nav>
  );
}
