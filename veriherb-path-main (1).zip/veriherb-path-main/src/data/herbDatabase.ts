export interface HerbInfo {
  id: string;
  commonName: string;
  scientificName: string;
  aliases: string[];
  region: string[];
  uses: string;
  benefits: string;
  transport: {
    method: string;
    temperature: string;
    humidity: string;
    packaging: string;
    shelfLife: string;
    specialNotes: string;
  };
  storage: {
    method: string;
    temperature: string;
    humidity: string;
    container: string;
    shelfLife: string;
    specialNotes: string;
  };
  allergies: string[];
  contraindications: string[];
  disadvantages: string[];
  doNotUseWith: string[];
  appearance: string;
  smell: string;
  consistency: string;
  similarHerbs: string[];
  remedies: {
    condition: string;
    preparation: string;
    dosage: string;
  }[];
  imageColor: string;
}

export const herbDatabase: HerbInfo[] = [
  {
    id: "ashwagandha",
    commonName: "Ashwagandha",
    scientificName: "Withania somnifera",
    aliases: ["Indian Ginseng", "Winter Cherry"],
    region: ["Rajasthan", "Madhya Pradesh", "Gujarat", "Maharashtra"],
    uses: "Used in powders, capsules, and traditional Ayurvedic formulations for stress relief and vitality.",
    benefits: "Adaptogenic properties, reduces cortisol, boosts stamina, improves sleep quality, supports thyroid function.",
    transport: {
      method: "Dried root in jute/cotton bags, refrigerated truck for extracts",
      temperature: "15–25°C",
      humidity: "Below 60%",
      packaging: "Food-grade HDPE bags with silica gel desiccants",
      shelfLife: "12–18 months during transit",
      specialNotes: "Avoid direct sunlight; keep away from strong-smelling goods"
    },
    storage: {
      method: "Store in airtight containers in cool, dark place",
      temperature: "Below 25°C",
      humidity: "Below 65%",
      container: "Glass jars, food-grade HDPE, or vacuum-sealed bags",
      shelfLife: "24 months (dried root), 18 months (powder)",
      specialNotes: "Check for moisture and pest infestation monthly"
    },
    allergies: ["May cause allergic reactions in people sensitive to nightshade family (Solanaceae)"],
    contraindications: ["Pregnant and breastfeeding women should avoid", "Do not use with sedative medications", "Avoid if you have autoimmune conditions like lupus, rheumatoid arthritis"],
    disadvantages: ["Large doses may cause stomach upset, diarrhea, and vomiting", "Can lower blood sugar excessively in diabetics on medication", "May increase thyroid hormone levels"],
    doNotUseWith: ["Sedatives (benzodiazepines)", "Thyroid medications", "Immunosuppressants", "Blood sugar-lowering drugs"],
    appearance: "Dried root is pale yellow-brown, cylindrical, 7–10 cm long with a woody texture",
    smell: "Distinct horse-like smell (hence the name 'ashwa' = horse)",
    consistency: "Dry, fibrous, and woody when raw; fine powder when processed",
    similarHerbs: ["shatavari", "ginseng"],
    remedies: [
      { condition: "Stress & Anxiety", preparation: "Mix 1 tsp ashwagandha powder in warm milk with honey before bed", dosage: "300–500mg twice daily" },
      { condition: "Insomnia", preparation: "Boil 1 tsp powder in 1 cup milk for 5 min, add jaggery", dosage: "Once at bedtime" },
      { condition: "Low Immunity", preparation: "Mix with equal parts giloy and tulsi powder, take with honey", dosage: "500mg twice daily" },
    ],
    imageColor: "hsl(38, 55%, 55%)"
  },
  {
    id: "tulsi",
    commonName: "Tulsi (Holy Basil)",
    scientificName: "Ocimum tenuiflorum",
    aliases: ["Holy Basil", "Sacred Basil", "Tulasi"],
    region: ["Kerala", "Karnataka", "Tamil Nadu", "Uttar Pradesh", "All of India"],
    uses: "Brewed into tea or eaten raw. Used in kadha (herbal decoction), puja rituals, and Ayurvedic syrups.",
    benefits: "Boosts immunity, common home remedy for coughs and colds, anti-inflammatory, adaptogenic.",
    transport: {
      method: "Fresh leaves in ventilated crates; dried in sealed bags",
      temperature: "2–8°C (fresh), 15–25°C (dried)",
      humidity: "85–90% (fresh), Below 60% (dried)",
      packaging: "Perforated polybags for fresh; vacuum-sealed for dried",
      shelfLife: "3–5 days (fresh), 12 months (dried)",
      specialNotes: "Fresh leaves bruise easily; handle with care"
    },
    storage: {
      method: "Refrigerate fresh leaves; store dried in airtight jars",
      temperature: "2–4°C (fresh), Room temp (dried)",
      humidity: "High (fresh), Below 60% (dried)",
      container: "Zip-lock bags (fresh), Glass/ceramic jars (dried)",
      shelfLife: "1 week (fresh), 12–18 months (dried)",
      specialNotes: "Wrap fresh leaves in damp paper towel"
    },
    allergies: ["Rare; may cause skin irritation in sensitive individuals when applied topically"],
    contraindications: ["May affect fertility; avoid excessive use when trying to conceive", "Use cautiously with blood-thinning medications"],
    disadvantages: ["Excessive consumption may lower blood sugar too much", "May slow blood clotting", "Eugenol in tulsi can cause liver damage in very high doses"],
    doNotUseWith: ["Anticoagulant drugs (warfarin, aspirin)", "Anti-diabetic medications (risk of hypoglycemia)"],
    appearance: "Small green or purple leaves, 2–5 cm, oval with serrated edges, on a woody stem",
    smell: "Strong, peppery, clove-like aroma with hints of mint",
    consistency: "Soft and tender when fresh; crumbly when dried",
    similarHerbs: ["mint", "basil"],
    remedies: [
      { condition: "Cold & Cough", preparation: "Boil 10–15 tulsi leaves in water with ginger and honey for kadha", dosage: "2–3 cups daily" },
      { condition: "Sore Throat", preparation: "Gargle with tulsi leaf decoction mixed with salt", dosage: "3 times daily" },
      { condition: "Fever", preparation: "Brew tulsi tea with black pepper and turmeric", dosage: "Every 4–6 hours" },
    ],
    imageColor: "hsl(145, 45%, 28%)"
  },
  {
    id: "turmeric",
    commonName: "Turmeric",
    scientificName: "Curcuma longa",
    aliases: ["Haldi", "Indian Saffron"],
    region: ["Andhra Pradesh", "Tamil Nadu", "Karnataka", "Odisha", "Maharashtra"],
    uses: "A staple in almost every Indian dish; also mixed with milk (golden milk/haldi doodh).",
    benefits: "Powerful anti-inflammatory and antiseptic properties. Contains curcumin which supports joint health and brain function.",
    transport: {
      method: "Dried rhizomes in jute bags; powder in food-grade pouches",
      temperature: "15–30°C",
      humidity: "Below 65%",
      packaging: "Multi-layer laminated pouches for powder; jute sacks for whole",
      shelfLife: "24 months (whole), 12 months (powder)",
      specialNotes: "Stains everything; use dedicated transport containers"
    },
    storage: {
      method: "Store in airtight containers away from light",
      temperature: "Room temperature, below 30°C",
      humidity: "Below 65%",
      container: "Dark glass jars or opaque airtight containers",
      shelfLife: "36 months (whole), 24 months (powder)",
      specialNotes: "Keep away from moisture to prevent mold; color fades in light"
    },
    allergies: ["May cause contact dermatitis in sensitive individuals", "Rare digestive allergies possible"],
    contraindications: ["Avoid high doses before surgery (blood thinning)", "Gallbladder problems — may worsen", "Iron deficiency — can inhibit iron absorption"],
    disadvantages: ["High doses may cause nausea, diarrhea, and stomach cramps", "Stains teeth and skin with prolonged topical use", "Poor bioavailability without black pepper (piperine)"],
    doNotUseWith: ["Blood thinners (warfarin, aspirin)", "Diabetes medications (additive blood sugar lowering)", "Antacids (increases stomach acid)"],
    appearance: "Fresh: knobby orange-yellow rhizome. Dried: hard, dark yellow-brown fingers",
    smell: "Warm, earthy, slightly peppery with a mustardy undertone",
    consistency: "Hard and woody when dry; fibrous and juicy when fresh",
    similarHerbs: ["ginger", "galangal"],
    remedies: [
      { condition: "Joint Pain", preparation: "Mix 1 tsp turmeric in warm milk with a pinch of black pepper (golden milk)", dosage: "Once daily at night" },
      { condition: "Wound Healing", preparation: "Make paste with turmeric powder and coconut oil, apply to wound", dosage: "Apply 2–3 times daily" },
      { condition: "Cold & Congestion", preparation: "Inhale steam from turmeric water or drink haldi doodh", dosage: "2 times daily" },
    ],
    imageColor: "hsl(38, 55%, 55%)"
  },
  {
    id: "coriander",
    commonName: "Coriander",
    scientificName: "Coriandrum sativum",
    aliases: ["Dhania", "Cilantro (leaves)"],
    region: ["Rajasthan", "Madhya Pradesh", "Gujarat", "Andhra Pradesh", "Tamil Nadu"],
    uses: "Used as a garnish for curries, in chutneys, soups, and as a spice (seeds).",
    benefits: "Aids digestion and acts as a cooling agent for the body. Rich in vitamins A, C, and K.",
    transport: {
      method: "Fresh bunches in chilled containers; seeds in jute/cotton bags",
      temperature: "0–4°C (fresh), 15–25°C (seeds)",
      humidity: "90–95% (fresh), Below 60% (seeds)",
      packaging: "Perforated poly bags (fresh); sealed pouches (seeds)",
      shelfLife: "5–7 days (fresh), 24 months (seeds)",
      specialNotes: "Fresh coriander is extremely perishable; needs cold chain"
    },
    storage: {
      method: "Wrap fresh in damp cloth and refrigerate; seeds in airtight jars",
      temperature: "0–4°C (fresh), Room temp (seeds)",
      humidity: "High (fresh), Below 60% (seeds)",
      container: "Zip-lock bags (fresh), Glass jars (seeds/powder)",
      shelfLife: "1–2 weeks (fresh), 2–3 years (whole seeds)",
      specialNotes: "Stand fresh coriander in a glass of water in the fridge"
    },
    allergies: ["Some people have a genetic aversion (tastes like soap — OR6A2 gene)", "Rare skin allergies from handling"],
    contraindications: ["Use cautiously if on blood pressure medications", "May lower blood sugar — monitor if diabetic"],
    disadvantages: ["Excessive consumption may cause photosensitivity", "Can cause digestive issues in very large amounts", "Strong flavor can overpower dishes"],
    doNotUseWith: ["Excessive use with blood pressure medications", "High doses alongside anticoagulants"],
    appearance: "Fresh: delicate, flat, fan-shaped bright green leaves on thin stems. Seeds: round, tan-brown, 3–5mm",
    smell: "Fresh leaves: bright, citrusy, slightly soapy. Seeds: warm, nutty, slightly sweet",
    consistency: "Leaves are tender and wilting; seeds are hard and crunchy",
    similarHerbs: ["parsley", "celery leaves"],
    remedies: [
      { condition: "Indigestion", preparation: "Soak 1 tbsp coriander seeds in water overnight, strain and drink", dosage: "Morning on empty stomach" },
      { condition: "Skin Rashes", preparation: "Apply fresh coriander leaf paste on affected area", dosage: "2–3 times daily" },
      { condition: "Eye Inflammation", preparation: "Wash eyes with cooled coriander seed water", dosage: "Twice daily" },
    ],
    imageColor: "hsl(120, 40%, 35%)"
  },
  {
    id: "mint",
    commonName: "Mint (Pudina)",
    scientificName: "Mentha spicata",
    aliases: ["Pudina", "Spearmint"],
    region: ["Punjab", "Himachal Pradesh", "Uttar Pradesh", "Jammu & Kashmir", "All of India"],
    uses: "Used in teas, biryanis, chutneys, and refreshing drinks like jaljeera.",
    benefits: "Helps with nausea, indigestion, and provides a cooling sensation. Freshens breath naturally.",
    transport: {
      method: "Fresh in refrigerated containers with moist lining; dried in sealed bags",
      temperature: "0–4°C (fresh), 15–25°C (dried)",
      humidity: "90–95% (fresh), Below 60% (dried)",
      packaging: "Ventilated plastic crates (fresh); vacuum-sealed (dried)",
      shelfLife: "3–5 days (fresh), 12 months (dried)",
      specialNotes: "Wilts rapidly at room temperature"
    },
    storage: {
      method: "Wrap in damp paper towel, store in airtight container in fridge",
      temperature: "0–4°C (fresh), Room temp (dried)",
      humidity: "High (fresh), Below 55% (dried)",
      container: "Airtight container in fridge (fresh), Glass jars (dried)",
      shelfLife: "1 week (fresh), 12–18 months (dried)",
      specialNotes: "Freeze in ice cube trays with water for long-term storage"
    },
    allergies: ["May cause allergic reactions in people sensitive to menthol", "Can trigger heartburn in GERD patients"],
    contraindications: ["Avoid in GERD/acid reflux — relaxes lower esophageal sphincter", "Not recommended for infants (menthol can affect breathing)"],
    disadvantages: ["Excessive use can cause headaches", "Menthol may interact with certain medications", "Can worsen acid reflux symptoms"],
    doNotUseWith: ["Acid reflux medications (counteracts them)", "Cyclosporine (mint affects drug absorption)", "Iron supplements (reduces absorption)"],
    appearance: "Bright green, oval leaves with serrated edges, 4–7cm long, on square stems",
    smell: "Strong, cool, refreshing menthol aroma",
    consistency: "Soft, tender, slightly fuzzy leaves",
    similarHerbs: ["tulsi", "basil", "lemon balm"],
    remedies: [
      { condition: "Nausea", preparation: "Steep 8–10 fresh mint leaves in hot water for 5 min", dosage: "Sip slowly as needed" },
      { condition: "Headache", preparation: "Apply crushed mint leaves on forehead or inhale mint oil", dosage: "As needed" },
      { condition: "Indigestion", preparation: "Chew fresh mint leaves after meals or drink mint tea", dosage: "After each meal" },
    ],
    imageColor: "hsl(145, 50%, 40%)"
  },
  {
    id: "curry-leaves",
    commonName: "Curry Leaves",
    scientificName: "Murraya koenigii",
    aliases: ["Kadi Patta", "Karivepaku", "Sweet Neem"],
    region: ["Karnataka", "Tamil Nadu", "Kerala", "Andhra Pradesh", "Maharashtra"],
    uses: "Used for tempering (tadka) in dals, sambar, and vegetable stir-fries.",
    benefits: "Rich in antioxidants and traditionally used to improve hair health. Aids digestion and reduces cholesterol.",
    transport: {
      method: "Fresh sprigs in ventilated crates with ice packs; dried in sealed pouches",
      temperature: "2–8°C (fresh), 15–25°C (dried)",
      humidity: "85–90% (fresh), Below 60% (dried)",
      packaging: "Perforated polybags with damp lining (fresh)",
      shelfLife: "5–7 days (fresh), 6 months (dried)",
      specialNotes: "Dried curry leaves lose most aroma; fresh is vastly preferred"
    },
    storage: {
      method: "Store fresh in airtight container in fridge; can be frozen",
      temperature: "2–4°C (fresh), -18°C (frozen)",
      humidity: "Moderate",
      container: "Zip-lock bags (remove air), airtight container",
      shelfLife: "2 weeks (fresh), 6 months (frozen), 3 months (dried)",
      specialNotes: "Freeze directly on stem for best flavor retention"
    },
    allergies: ["Very rare; generally considered hypoallergenic", "May cause mild stomach upset in excess"],
    contraindications: ["Consult doctor if on diabetes medication (additive blood sugar lowering)"],
    disadvantages: ["Dried leaves lose significant flavor and aroma", "Can cause low blood sugar in excess", "Seeds are toxic and should never be consumed"],
    doNotUseWith: ["Excessive use with anti-diabetic drugs"],
    appearance: "Small, shiny, dark green pinnate leaves, 2–4cm each, arranged on a stem",
    smell: "Strong, nutty, aromatic with a distinctive curry-like fragrance",
    consistency: "Smooth, slightly waxy, tender when fresh",
    similarHerbs: ["neem", "moringa leaves"],
    remedies: [
      { condition: "Hair Loss", preparation: "Boil curry leaves in coconut oil until black, strain and apply to scalp", dosage: "2–3 times per week" },
      { condition: "Diabetes Support", preparation: "Eat 8–10 fresh curry leaves on empty stomach daily", dosage: "Daily morning" },
      { condition: "Nausea & Morning Sickness", preparation: "Crush curry leaves, add to buttermilk with cumin", dosage: "Once daily" },
    ],
    imageColor: "hsl(130, 45%, 30%)"
  },
  {
    id: "ginger",
    commonName: "Ginger",
    scientificName: "Zingiber officinale",
    aliases: ["Adrak", "Sonth (dried)"],
    region: ["Kerala", "Karnataka", "Assam", "Meghalaya", "Arunachal Pradesh"],
    uses: "Used in tea, marinades, stir-fries, and as a key spice in Indian cooking.",
    benefits: "Excellent for relieving motion sickness, sore throats, and bloating. Anti-nausea and anti-inflammatory.",
    transport: {
      method: "Fresh rhizomes in ventilated crates; dried (sonth) in jute bags",
      temperature: "12–14°C (fresh), 15–25°C (dried)",
      humidity: "65–70% (fresh), Below 60% (dried)",
      packaging: "Wooden/plastic crates with newspaper padding (fresh)",
      shelfLife: "2–3 weeks (fresh), 24 months (dried)",
      specialNotes: "Avoid refrigeration below 10°C — causes chilling injury"
    },
    storage: {
      method: "Store fresh unpeeled in fridge; dried in airtight container",
      temperature: "12–14°C (fresh), Room temp (dried)",
      humidity: "65% (fresh), Below 60% (dried)",
      container: "Paper bag in fridge (fresh), Glass jar (dried/powder)",
      shelfLife: "3–4 weeks (fresh), 2–3 years (dried whole)",
      specialNotes: "Freeze grated ginger in portions for long-term use"
    },
    allergies: ["Rare; may cause mouth irritation or heartburn in sensitive people"],
    contraindications: ["Avoid high doses before surgery (blood thinning)", "Gallstone patients should consult doctor"],
    disadvantages: ["Excessive consumption can cause heartburn and diarrhea", "May interact with blood-thinning medications", "Can irritate the mouth and throat in raw form"],
    doNotUseWith: ["Blood thinners (warfarin)", "High blood pressure medications", "Diabetes medications (additive effect)"],
    appearance: "Knobby, irregular rhizome, pale yellow to brown skin, yellow flesh inside",
    smell: "Sharp, warm, spicy-sweet aroma with citrus notes",
    consistency: "Firm and fibrous when fresh; hard and woody when dried",
    similarHerbs: ["turmeric", "galangal"],
    remedies: [
      { condition: "Nausea & Motion Sickness", preparation: "Chew small piece of fresh ginger or sip ginger tea", dosage: "As needed" },
      { condition: "Sore Throat", preparation: "Boil ginger slices with lemon and honey in water", dosage: "3 times daily" },
      { condition: "Bloating & Gas", preparation: "Grate fresh ginger, add to warm water with lemon", dosage: "After meals" },
    ],
    imageColor: "hsl(38, 50%, 50%)"
  },
  {
    id: "rosemary",
    commonName: "Rosemary",
    scientificName: "Salvia rosmarinus",
    aliases: ["Gulmehendi"],
    region: ["Himachal Pradesh", "Uttarakhand", "Kashmir", "Nilgiri Hills"],
    uses: "Mostly used in Western cooking for seasoning roasted vegetables, pasta, and meats.",
    benefits: "Often linked to improved concentration and memory when used in aromatherapy. Rich in antioxidants.",
    transport: {
      method: "Fresh sprigs in chilled containers; dried in sealed bags",
      temperature: "2–4°C (fresh), 15–25°C (dried)",
      humidity: "90% (fresh), Below 55% (dried)",
      packaging: "Clamshell containers (fresh), Sealed pouches (dried)",
      shelfLife: "7–10 days (fresh), 12–24 months (dried)",
      specialNotes: "Hardy herb; tolerates transport better than most fresh herbs"
    },
    storage: {
      method: "Wrap in damp paper towel in fridge; dried in airtight jar",
      temperature: "2–4°C (fresh), Room temp (dried)",
      humidity: "Moderate (fresh), Low (dried)",
      container: "Zip-lock bag (fresh), Dark glass jar (dried)",
      shelfLife: "2 weeks (fresh), 1–3 years (dried)",
      specialNotes: "Can be dried by hanging upside down in a warm, dry place"
    },
    allergies: ["May cause allergic reactions in people sensitive to Lamiaceae family"],
    contraindications: ["Avoid large amounts during pregnancy", "Epilepsy patients should use cautiously"],
    disadvantages: ["Very high doses can cause vomiting and seizures", "Rosemary oil should never be ingested pure", "Can cause photosensitivity"],
    doNotUseWith: ["ACE inhibitors (blood pressure drugs)", "Lithium", "Diuretics (water pills)"],
    appearance: "Needle-like, dark green leaves on woody stems, 2–4cm long",
    smell: "Strong, piney, camphor-like with woody undertones",
    consistency: "Tough, leathery leaves; woody stems",
    similarHerbs: ["thyme", "lavender"],
    remedies: [
      { condition: "Poor Concentration", preparation: "Inhale rosemary essential oil or brew rosemary tea", dosage: "During study/work sessions" },
      { condition: "Hair Growth", preparation: "Steep rosemary in warm olive oil for 2 hours, massage into scalp", dosage: "2 times per week" },
      { condition: "Muscle Pain", preparation: "Add rosemary sprigs to warm bath water", dosage: "15–20 min soak" },
    ],
    imageColor: "hsl(150, 35%, 35%)"
  },
  {
    id: "thyme",
    commonName: "Thyme",
    scientificName: "Thymus vulgaris",
    aliases: ["Ajwain ke phool (sometimes confused)"],
    region: ["Himachal Pradesh", "Uttarakhand", "Kashmir", "Western Ghats"],
    uses: "Used for seasoning roasted vegetables, soups, stews, and Mediterranean-style cooking.",
    benefits: "Natural antiseptic, supports respiratory health, and boosts immunity.",
    transport: {
      method: "Fresh sprigs in chilled crates; dried in sealed bags",
      temperature: "2–4°C (fresh), 15–25°C (dried)",
      humidity: "85% (fresh), Below 55% (dried)",
      packaging: "Clamshell packs (fresh), vacuum-sealed (dried)",
      shelfLife: "7–10 days (fresh), 24 months (dried)",
      specialNotes: "Small leaves dry well and retain flavor"
    },
    storage: {
      method: "Refrigerate fresh; store dried in airtight containers",
      temperature: "2–4°C (fresh), Room temp (dried)",
      humidity: "Moderate (fresh), Low (dried)",
      container: "Damp paper towel in bag (fresh), Glass jar (dried)",
      shelfLife: "1–2 weeks (fresh), 2–3 years (dried)",
      specialNotes: "Dried thyme is often more potent than fresh"
    },
    allergies: ["Allergy risk for people sensitive to oregano, lavender, or mint family"],
    contraindications: ["Avoid thyme oil internally during pregnancy", "Hormone-sensitive conditions (estrogenic effect)"],
    disadvantages: ["Thyme oil can cause skin irritation undiluted", "Very high doses may cause digestive issues", "Can slow blood clotting"],
    doNotUseWith: ["Anticoagulants", "Hormone therapy drugs", "Thyme oil internally without supervision"],
    appearance: "Tiny, oval, grey-green leaves (3–8mm) on thin woody stems",
    smell: "Warm, pungent, slightly minty with earthy undertones",
    consistency: "Small, slightly fuzzy leaves; woody stems",
    similarHerbs: ["oregano", "rosemary"],
    remedies: [
      { condition: "Cough & Bronchitis", preparation: "Steep 2 tsp dried thyme in hot water for 10 min, add honey", dosage: "3 cups daily" },
      { condition: "Sore Throat", preparation: "Gargle with strong thyme tea (cooled)", dosage: "3–4 times daily" },
      { condition: "Fungal Infections", preparation: "Apply diluted thyme oil (with carrier oil) to affected area", dosage: "Twice daily" },
    ],
    imageColor: "hsl(120, 20%, 40%)"
  },
  {
    id: "aloe-vera",
    commonName: "Aloe Vera",
    scientificName: "Aloe barbadensis miller",
    aliases: ["Ghritkumari", "Gwarpatha"],
    region: ["Rajasthan", "Gujarat", "Maharashtra", "Andhra Pradesh", "Tamil Nadu"],
    uses: "The gel is applied topically or consumed in juice form. Used in cosmetics and health drinks.",
    benefits: "Known for soothing skin burns, hydrating the skin, and supporting gut health.",
    transport: {
      method: "Whole leaves wrapped in paper; gel in refrigerated containers",
      temperature: "7–10°C (leaves), 2–4°C (gel)",
      humidity: "Moderate",
      packaging: "Wrapped individually; gel in food-grade plastic tubs",
      shelfLife: "2 weeks (leaves), 5 days (fresh gel)",
      specialNotes: "Gel oxidizes quickly; process within hours of cutting"
    },
    storage: {
      method: "Refrigerate leaves whole; gel must be refrigerated or frozen",
      temperature: "2–8°C",
      humidity: "Moderate",
      container: "Airtight containers for gel; leaves stored as-is",
      shelfLife: "2–3 weeks (whole leaf), 1 week (gel), 6 months (frozen gel)",
      specialNotes: "Add vitamin C (lemon juice) to fresh gel to prevent oxidation"
    },
    allergies: ["Can cause contact dermatitis in sensitive individuals", "Oral consumption may cause allergic reactions in latex-sensitive people"],
    contraindications: ["Do not consume latex layer (yellow substance under skin) — causes severe cramps", "Avoid oral use during pregnancy", "Not for children under 12 internally"],
    disadvantages: ["Internal use can cause diarrhea and electrolyte imbalance", "The latex (aloin) is a harsh laxative", "Topical use may delay wound healing in deep cuts", "May cause liver issues with prolonged internal use"],
    doNotUseWith: ["Diuretics (potassium depletion)", "Diabetes medications (blood sugar drop)", "Laxatives (compounding effect)", "Digoxin (heart medication)"],
    appearance: "Thick, fleshy, spear-shaped green leaves with spiny edges, growing in rosette",
    smell: "Mild, slightly grassy, the gel is nearly odorless",
    consistency: "Outer leaf is firm and rubbery; inner gel is clear, slimy, and viscous",
    similarHerbs: ["agave"],
    remedies: [
      { condition: "Sunburn & Burns", preparation: "Apply fresh aloe vera gel directly on affected skin", dosage: "3–4 times daily" },
      { condition: "Constipation", preparation: "Mix 2 tbsp aloe vera juice in water (ensure latex-free)", dosage: "Once daily, short-term" },
      { condition: "Dry Skin", preparation: "Apply fresh gel as overnight face mask", dosage: "3 times per week" },
    ],
    imageColor: "hsl(120, 45%, 45%)"
  },
  {
    id: "fenugreek",
    commonName: "Fenugreek (Methi)",
    scientificName: "Trigonella foenum-graecum",
    aliases: ["Methi", "Kasuri Methi (dried leaves)"],
    region: ["Rajasthan", "Madhya Pradesh", "Gujarat", "Uttar Pradesh", "Maharashtra"],
    uses: "Seeds are used in tempering; fresh leaves (methi) used in parathas, curries. Dried leaves (kasuri methi) for garnishing.",
    benefits: "Traditionally used to help manage blood sugar levels and improve digestion. Supports lactation in nursing mothers.",
    transport: {
      method: "Fresh leaves in chilled crates; seeds in jute bags",
      temperature: "2–4°C (fresh), 15–25°C (seeds)",
      humidity: "90% (fresh), Below 60% (seeds)",
      packaging: "Ventilated crates (fresh), Cloth/jute bags (seeds)",
      shelfLife: "3–5 days (fresh), 36 months (seeds)",
      specialNotes: "Fresh methi is very perishable and turns yellow quickly"
    },
    storage: {
      method: "Refrigerate fresh; seeds in airtight jars at room temp",
      temperature: "2–4°C (fresh), Room temp (seeds)",
      humidity: "High (fresh), Below 60% (seeds)",
      container: "Perforated bags (fresh), Glass jars (seeds)",
      shelfLife: "1 week (fresh), 3+ years (seeds), 6 months (kasuri methi)",
      specialNotes: "Soak seeds overnight before use for better digestibility"
    },
    allergies: ["May cause allergic reactions in people allergic to chickpeas, peanuts (same family)", "Can cause maple-syrup-like body odor"],
    contraindications: ["Pregnant women should avoid (may induce contractions)", "Use cautiously with diabetes medications"],
    disadvantages: ["Bitter taste can be off-putting", "Causes a strong, maple-syrup-like body odor", "May cause bloating and gas initially", "Can cause diarrhea in large doses"],
    doNotUseWith: ["Blood thinners (additive effect)", "Diabetes medications (additive blood sugar drop)", "Thyroid medications (may interfere with absorption)"],
    appearance: "Fresh: small, trifoliate green leaves. Seeds: small, hard, yellow-brown, angular",
    smell: "Seeds: strong, bitter, maple-syrup-like. Leaves: mildly bitter, hay-like",
    consistency: "Seeds are hard and angular; fresh leaves are tender; dried (kasuri) are crumbly",
    similarHerbs: ["clover", "alfalfa"],
    remedies: [
      { condition: "Diabetes Support", preparation: "Soak 1 tbsp seeds overnight, eat on empty stomach with water", dosage: "Daily morning" },
      { condition: "Low Breast Milk", preparation: "Add methi seeds to dal or eat methi laddoos", dosage: "2–3 times daily" },
      { condition: "Hair Fall", preparation: "Soak seeds, grind to paste, apply to scalp for 30 min", dosage: "2 times per week" },
    ],
    imageColor: "hsl(90, 40%, 40%)"
  },
  {
    id: "neem",
    commonName: "Neem",
    scientificName: "Azadirachta indica",
    aliases: ["Nimba", "Margosa"],
    region: ["Rajasthan", "Uttar Pradesh", "Tamil Nadu", "Andhra Pradesh", "Maharashtra", "All of India"],
    uses: "Used in skincare (soaps/pastes) or consumed in very small quantities. Neem twigs used as natural toothbrush.",
    benefits: "Strong antibacterial and antifungal properties. Often used to treat skin conditions and purify blood.",
    transport: {
      method: "Fresh leaves in ventilated containers; neem oil in sealed drums",
      temperature: "Room temperature",
      humidity: "Below 65%",
      packaging: "Breathable bags (leaves), HDPE drums (oil), Sealed pouches (powder)",
      shelfLife: "3–5 days (fresh), 24 months (powder), 36 months (oil)",
      specialNotes: "Extremely bitter; store separately from food items"
    },
    storage: {
      method: "Fresh leaves in cool area; oil and powder in dark, cool storage",
      temperature: "Room temperature, below 30°C",
      humidity: "Below 60%",
      container: "Breathable cloth bags (leaves), Dark glass (oil), Airtight jars (powder)",
      shelfLife: "1 week (fresh), 2 years (powder), 3 years (oil)",
      specialNotes: "Neem oil solidifies below 20°C — this is normal"
    },
    allergies: ["May cause allergic reactions in sensitive individuals", "Neem oil can cause skin irritation if applied undiluted"],
    contraindications: ["TOXIC in large internal doses", "Never give neem oil to children internally", "Avoid during pregnancy and breastfeeding", "Not for people with autoimmune disorders"],
    disadvantages: ["Extremely bitter taste", "Internal overdose can cause organ damage", "Neem oil has a very strong, unpleasant smell", "Can lower fertility (traditional contraceptive use)"],
    doNotUseWith: ["Immunosuppressant medications", "Diabetes medications (additive blood sugar drop)", "Lithium", "Never give neem oil internally to children"],
    appearance: "Pinnate compound leaves with 8–15 leaflets per branch, each leaflet 3–8cm, with serrated edges",
    smell: "Leaves: slightly garlicky, bitter. Oil: strong, pungent, sulfurous",
    consistency: "Leaves are thin and slightly glossy; bark is rough and grey-brown",
    similarHerbs: ["curry-leaves", "chinaberry"],
    remedies: [
      { condition: "Skin Infections", preparation: "Boil neem leaves, use the cooled water to wash affected area", dosage: "2 times daily" },
      { condition: "Dandruff", preparation: "Boil neem leaves, cool, and use as final hair rinse", dosage: "2–3 times per week" },
      { condition: "Blood Purification", preparation: "Eat 4–5 fresh neem leaves on empty stomach (with honey if bitter)", dosage: "Daily for 2 weeks, then break" },
    ],
    imageColor: "hsl(140, 40%, 30%)"
  },
  {
    id: "amla",
    commonName: "Amla",
    scientificName: "Phyllanthus emblica",
    aliases: ["Indian Gooseberry", "Amalaki"],
    region: ["Uttar Pradesh", "Madhya Pradesh", "Rajasthan", "Tamil Nadu"],
    uses: "Eaten raw, in pickles, chutneys, juices, and as Chyawanprash ingredient.",
    benefits: "Richest natural source of Vitamin C. Boosts immunity, improves hair and skin health, aids digestion.",
    transport: {
      method: "Fresh fruits in ventilated wooden crates; dried/powder in sealed bags",
      temperature: "8–10°C (fresh), 15–25°C (dried)",
      humidity: "85% (fresh), Below 60% (dried)",
      packaging: "Wooden crates with straw cushioning (fresh)",
      shelfLife: "2–3 weeks (fresh), 24 months (dried/powder)",
      specialNotes: "Bruises easily; handle gently during transit"
    },
    storage: {
      method: "Refrigerate fresh; store powder/dried in airtight containers",
      temperature: "4–8°C (fresh), Room temp (dried)",
      humidity: "Moderate (fresh), Below 60% (dried)",
      container: "Paper bags in fridge (fresh), Glass jars (powder)",
      shelfLife: "3–4 weeks (fresh), 2 years (powder)",
      specialNotes: "Can be preserved as murabba (jam) for extended shelf life"
    },
    allergies: ["May cause acid reflux in sensitive individuals", "Rarely, skin rashes from topical use"],
    contraindications: ["Avoid before surgery (blood thinning)", "May worsen bleeding disorders"],
    disadvantages: ["Very sour and astringent taste", "May cause constipation in some people", "Can lower blood sugar excessively with medications"],
    doNotUseWith: ["Blood thinners", "Diabetes medications in excess", "Antacids (interferes with absorption)"],
    appearance: "Small, round, translucent green-yellow fruit, 2–3cm diameter, with 6 vertical stripes",
    smell: "Mildly fruity with a sour tang",
    consistency: "Firm, fibrous flesh; very juicy and crunchy when fresh",
    similarHerbs: ["gooseberry"],
    remedies: [
      { condition: "Low Immunity", preparation: "Eat 1–2 fresh amla daily or drink amla juice with honey", dosage: "Daily" },
      { condition: "Hair Health", preparation: "Mix amla powder with coconut oil, apply to scalp", dosage: "2 times per week" },
      { condition: "Acidity", preparation: "Drink amla juice diluted with water on empty stomach", dosage: "Morning daily" },
    ],
    imageColor: "hsl(80, 45%, 45%)"
  },
  {
    id: "shatavari",
    commonName: "Shatavari",
    scientificName: "Asparagus racemosus",
    aliases: ["Queen of Herbs", "Wild Asparagus"],
    region: ["Rajasthan", "Uttarakhand", "Himachal Pradesh", "Gujarat"],
    uses: "Root powder in milk, capsules, and traditional Ayurvedic tonics.",
    benefits: "Female reproductive health, hormonal balance, digestive support, immunity booster.",
    transport: {
      method: "Dried root in cotton/jute bags",
      temperature: "15–25°C",
      humidity: "Below 60%",
      packaging: "Food-grade bags with desiccants",
      shelfLife: "18–24 months",
      specialNotes: "Protect from moisture and direct sunlight"
    },
    storage: {
      method: "Store in airtight containers in cool, dark place",
      temperature: "Below 25°C",
      humidity: "Below 60%",
      container: "Glass jars or vacuum-sealed bags",
      shelfLife: "24 months (powder), 36 months (dried root)",
      specialNotes: "Check for insect infestation periodically"
    },
    allergies: ["Avoid if allergic to asparagus family"],
    contraindications: ["Avoid in estrogen-sensitive conditions", "Not recommended during active kidney disorders"],
    disadvantages: ["May cause weight gain with prolonged use", "Can cause bloating initially", "Strong, sweet taste not preferred by all"],
    doNotUseWith: ["Diuretics", "Estrogen medications", "Lithium"],
    appearance: "Dried root is pale white-yellow, long, finger-like tuberous roots",
    smell: "Mild, sweet, slightly earthy",
    consistency: "Dried roots are hard and fibrous; powder is fine and pale",
    similarHerbs: ["ashwagandha"],
    remedies: [
      { condition: "Hormonal Balance", preparation: "Mix 1 tsp shatavari powder in warm milk with ghee", dosage: "Twice daily" },
      { condition: "Digestive Issues", preparation: "Take shatavari powder with warm water and honey", dosage: "Once daily" },
      { condition: "Low Immunity", preparation: "Mix with ashwagandha powder in equal parts, take with milk", dosage: "Once daily" },
    ],
    imageColor: "hsl(60, 30%, 50%)"
  },
];

export function findHerbByName(query: string): HerbInfo | undefined {
  const q = query.toLowerCase();
  return herbDatabase.find(h =>
    h.commonName.toLowerCase().includes(q) ||
    h.scientificName.toLowerCase().includes(q) ||
    h.aliases.some(a => a.toLowerCase().includes(q)) ||
    h.id.toLowerCase().includes(q)
  );
}

export function getHerbsByRegion(region: string): HerbInfo[] {
  const r = region.toLowerCase();
  return herbDatabase.filter(h =>
    h.region.some(reg => reg.toLowerCase().includes(r)) ||
    h.region.includes("All of India")
  );
}

export const indianRegions = [
  "Rajasthan", "Madhya Pradesh", "Gujarat", "Maharashtra", "Kerala",
  "Karnataka", "Tamil Nadu", "Andhra Pradesh", "Uttar Pradesh",
  "Uttarakhand", "Himachal Pradesh", "Punjab", "Jammu & Kashmir",
  "Assam", "Meghalaya", "Odisha", "West Bengal", "Bihar",
  "Arunachal Pradesh", "Telangana", "Goa"
];
