export interface FarmerAlert {
  id: string;
  type: "flood" | "heavy-rain" | "fire" | "drought" | "cyclone" | "frost" | "hailstorm";
  severity: "warning" | "critical" | "info";
  title: string;
  description: string;
  affectedRegions: string[];
  timestamp: string;
  isActive: boolean;
  guidance: {
    step: number;
    action: string;
    detail: string;
  }[];
  cropProtection: string[];
}

export const farmerAlerts: FarmerAlert[] = [
  {
    id: "ALT-001",
    type: "heavy-rain",
    severity: "warning",
    title: "Heavy Rainfall Alert – Western Rajasthan",
    description: "IMD predicts 150–200mm rainfall over next 48 hours. Risk of waterlogging in low-lying herb fields.",
    affectedRegions: ["Rajasthan", "Gujarat"],
    timestamp: "2025-04-02T08:00:00Z",
    isActive: true,
    guidance: [
      { step: 1, action: "Drain fields immediately", detail: "Create drainage channels to prevent waterlogging. Ashwagandha roots rot quickly in standing water." },
      { step: 2, action: "Cover drying herbs", detail: "Move any herbs being sun-dried to covered areas. Use tarpaulins if no shed is available." },
      { step: 3, action: "Harvest mature crops early", detail: "If ashwagandha or shatavari roots are near harvest stage, consider early harvest to prevent water damage." },
      { step: 4, action: "Secure storage facilities", detail: "Ensure stored herbs are elevated off the ground and containers are sealed against moisture." },
      { step: 5, action: "Document damage", detail: "Photograph any crop damage for insurance claims and blockchain records." },
    ],
    cropProtection: [
      "Apply fungicide spray on turmeric and ginger beds to prevent rhizome rot",
      "Stake tulsi plants to prevent lodging from wind",
      "Cover fenugreek beds with shade nets to reduce physical damage",
    ],
  },
  {
    id: "ALT-002",
    type: "flood",
    severity: "critical",
    title: "Flood Warning – Kerala Lowlands",
    description: "River levels rising above danger mark. Flash floods expected in Wayanad and Idukki districts.",
    affectedRegions: ["Kerala", "Karnataka"],
    timestamp: "2025-04-01T14:00:00Z",
    isActive: true,
    guidance: [
      { step: 1, action: "Evacuate low-lying areas", detail: "Move to higher ground immediately. Carry essential documents and seed stocks." },
      { step: 2, action: "Relocate harvested stock", detail: "Transport all dried and processed herbs to elevated storage. Priority: tulsi, curry leaves, ginger." },
      { step: 3, action: "Secure livestock and equipment", detail: "Move tools, IoT sensors, and GPS equipment to safe locations." },
      { step: 4, action: "Contact cooperative coordinator", detail: "Report status to your cooperative for coordinated relief and supply chain updates." },
      { step: 5, action: "Post-flood soil treatment", detail: "After water recedes, test soil pH and apply lime if acidified. Wait 1 week before replanting." },
    ],
    cropProtection: [
      "Ginger and turmeric rhizomes: harvest immediately if possible",
      "Curry leaf trees: ensure drainage around root zone",
      "Neem trees are flood-resilient but check for root exposure after waters recede",
    ],
  },
  {
    id: "ALT-003",
    type: "fire",
    severity: "critical",
    title: "Forest Fire Risk – Uttarakhand Hills",
    description: "Dry conditions and high winds creating fire risk near wild collection zones for rosemary and thyme.",
    affectedRegions: ["Uttarakhand", "Himachal Pradesh"],
    timestamp: "2025-04-03T06:00:00Z",
    isActive: true,
    guidance: [
      { step: 1, action: "Create firebreaks", detail: "Clear 3–5 meter strips of vegetation around herb cultivation areas." },
      { step: 2, action: "Stop wild collection temporarily", detail: "Suspend forest herb collection until fire risk subsides." },
      { step: 3, action: "Keep water sources ready", detail: "Fill all available tanks and containers. Position near herb drying sheds." },
      { step: 4, action: "Remove dry plant material", detail: "Clear fallen leaves and dry branches near processing and storage areas." },
      { step: 5, action: "Emergency contact readiness", detail: "Keep forest department and fire service numbers accessible. Report any smoke immediately." },
    ],
    cropProtection: [
      "Rosemary bushes: water thoroughly to reduce fire susceptibility",
      "Dried herb stocks are highly flammable — relocate from fire-prone areas",
      "Cover herb beds with damp burlap as temporary fire retardant",
    ],
  },
  {
    id: "ALT-004",
    type: "drought",
    severity: "warning",
    title: "Drought Advisory – Madhya Pradesh",
    description: "Below-normal rainfall expected. Water conservation critical for herb cultivation zones.",
    affectedRegions: ["Madhya Pradesh", "Maharashtra"],
    timestamp: "2025-03-28T10:00:00Z",
    isActive: false,
    guidance: [
      { step: 1, action: "Switch to drip irrigation", detail: "Reduce water usage by 60% with drip irrigation for ashwagandha and aloe vera." },
      { step: 2, action: "Apply mulching", detail: "Use organic mulch around turmeric and fenugreek to retain soil moisture." },
      { step: 3, action: "Prioritize drought-resistant species", detail: "Focus on aloe vera, neem, and ashwagandha which tolerate dry conditions." },
      { step: 4, action: "Reduce harvest pressure", detail: "Limit wild collection to allow natural regeneration during water stress." },
      { step: 5, action: "Rainwater harvesting", detail: "Set up collection systems for any unexpected rain events." },
    ],
    cropProtection: [
      "Aloe vera thrives in drought — this is ideal growing condition",
      "Reduce watering frequency for ashwagandha (naturally drought-tolerant)",
      "Avoid planting water-intensive herbs like mint and coriander until rains return",
    ],
  },
];
