import { Batch, CollectionEvent, QualityTest, ProcessingStep, NetworkNode, DashboardMetrics } from "./types";

const generateHash = () => "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("");

export const networkNodes: NetworkNode[] = [
  { id: "N1", name: "Rajasthan Farmers Cooperative", type: "cooperative", location: "Nagaur, Rajasthan", latitude: 27.2, longitude: 73.18, isActive: true, transactionCount: 342 },
  { id: "N2", name: "Madhya Pradesh Wild Collectors", type: "collector", location: "Dhar, Madhya Pradesh", latitude: 22.6, longitude: 75.3, isActive: true, transactionCount: 218 },
  { id: "N3", name: "AYUSH Certified Lab – Jaipur", type: "lab", location: "Jaipur, Rajasthan", latitude: 26.9, longitude: 75.8, isActive: true, transactionCount: 567 },
  { id: "N4", name: "Herbal Processing Unit – Indore", type: "processor", location: "Indore, Madhya Pradesh", latitude: 22.72, longitude: 75.86, isActive: true, transactionCount: 189 },
  { id: "N5", name: "AyurVeda Formulations Pvt Ltd", type: "manufacturer", location: "Haridwar, Uttarakhand", latitude: 29.95, longitude: 78.16, isActive: true, transactionCount: 423 },
  { id: "N6", name: "Kerala Collectors Guild", type: "collector", location: "Wayanad, Kerala", latitude: 11.6, longitude: 76.08, isActive: true, transactionCount: 156 },
  { id: "N7", name: "National Testing Lab – Delhi", type: "lab", location: "New Delhi", latitude: 28.61, longitude: 77.23, isActive: true, transactionCount: 312 },
  { id: "N8", name: "Organic India Retail", type: "retailer", location: "Lucknow, UP", latitude: 26.85, longitude: 80.95, isActive: true, transactionCount: 89 },
];

const ashwagandhaCollection: CollectionEvent = {
  id: "CE-001", batchId: "BATCH-ASH-2025-001", species: "Withania somnifera", commonName: "Ashwagandha",
  collectorId: "COL-R12", collectorName: "Ramesh Sharma", cooperativeName: "Rajasthan Farmers Cooperative",
  latitude: 27.2015, longitude: 73.1822, altitude: 310, timestamp: "2025-03-15T06:30:00Z",
  harvestMethod: "cultivated", soilMoisture: 22.5, ambientTemp: 28, humidity: 45,
  initialWeight: 125.5, qualityGrade: "A", geoFenceApproved: true, seasonalApproved: true,
  sustainabilityScore: 92, blockHash: generateHash(), txHash: generateHash(),
};

const ashwagandhaQuality: QualityTest = {
  id: "QT-001", batchId: "BATCH-ASH-2025-001", labId: "LAB-JP-01", labName: "AYUSH Certified Lab – Jaipur",
  testDate: "2025-03-18T10:00:00Z", moistureContent: 8.2, moisturePass: true,
  pesticideLevel: 0.003, pesticidePass: true, heavyMetals: 0.05, heavyMetalsPass: true,
  dnaBarcodeMatch: true, microbialCount: 150, microbialPass: true,
  aflatoxinLevel: 1.2, aflatoxinPass: true, overallPass: true,
  certificateUrl: "#", blockHash: generateHash(), txHash: generateHash(),
};

const ashwagandhaProcessing: ProcessingStep[] = [
  { id: "PS-001", batchId: "BATCH-ASH-2025-001", facilityId: "FAC-IND-01", facilityName: "Herbal Processing Unit – Indore",
    stepType: "drying", startTime: "2025-03-20T08:00:00Z", endTime: "2025-03-22T08:00:00Z",
    temperature: 45, humidity: 15, inputWeight: 125.5, outputWeight: 42.3,
    operatorId: "OP-045", notes: "Sun-dried per traditional method, shade-covered", blockHash: generateHash(), txHash: generateHash() },
  { id: "PS-002", batchId: "BATCH-ASH-2025-001", facilityId: "FAC-IND-01", facilityName: "Herbal Processing Unit – Indore",
    stepType: "grinding", startTime: "2025-03-23T09:00:00Z", endTime: "2025-03-23T14:00:00Z",
    temperature: 25, humidity: 30, inputWeight: 42.3, outputWeight: 41.8,
    operatorId: "OP-045", notes: "Stone-ground to 80 mesh", blockHash: generateHash(), txHash: generateHash() },
  { id: "PS-003", batchId: "BATCH-ASH-2025-001", facilityId: "FAC-HDW-01", facilityName: "AyurVeda Formulations Pvt Ltd",
    stepType: "blending", startTime: "2025-03-25T10:00:00Z", endTime: "2025-03-25T16:00:00Z",
    temperature: 22, humidity: 40, inputWeight: 41.8, outputWeight: 50.0,
    operatorId: "OP-112", notes: "Blended with black pepper extract for bioavailability", blockHash: generateHash(), txHash: generateHash() },
  { id: "PS-004", batchId: "BATCH-ASH-2025-001", facilityId: "FAC-HDW-01", facilityName: "AyurVeda Formulations Pvt Ltd",
    stepType: "packaging", startTime: "2025-03-26T08:00:00Z", endTime: "2025-03-26T17:00:00Z",
    temperature: 22, humidity: 35, inputWeight: 50.0, outputWeight: 50.0,
    operatorId: "OP-113", notes: "500mg capsules, 60 per bottle, nitrogen-flushed", blockHash: generateHash(), txHash: generateHash() },
];

export const batches: Batch[] = [
  {
    id: "BATCH-ASH-2025-001", qrCode: "QR-ASH-001-2025", species: "Withania somnifera", commonName: "Ashwagandha",
    productName: "Ashwagandha Root Extract Capsules", status: "retail",
    collectionEvents: [ashwagandhaCollection], qualityTests: [ashwagandhaQuality], processingSteps: ashwagandhaProcessing,
    finalWeight: 50.0, sustainabilityScore: 92, fairTradeVerified: true,
    createdAt: "2025-03-15T06:30:00Z", updatedAt: "2025-03-26T17:00:00Z",
  },
  {
    id: "BATCH-TUL-2025-002", qrCode: "QR-TUL-002-2025", species: "Ocimum tenuiflorum", commonName: "Tulsi (Holy Basil)",
    productName: "Tulsi Green Tea Blend", status: "processing",
    collectionEvents: [{
      ...ashwagandhaCollection, id: "CE-002", batchId: "BATCH-TUL-2025-002", species: "Ocimum tenuiflorum", commonName: "Tulsi",
      collectorName: "Priya Devi", cooperativeName: "Kerala Collectors Guild",
      latitude: 11.605, longitude: 76.083, altitude: 780, timestamp: "2025-03-10T07:00:00Z",
      harvestMethod: "wild-collection", initialWeight: 85.0, sustainabilityScore: 88,
    }],
    qualityTests: [{
      ...ashwagandhaQuality, id: "QT-002", batchId: "BATCH-TUL-2025-002", testDate: "2025-03-13T10:00:00Z",
      labName: "National Testing Lab – Delhi", labId: "LAB-DL-01",
    }],
    processingSteps: [ashwagandhaProcessing[0]],
    finalWeight: 30.0, sustainabilityScore: 88, fairTradeVerified: true,
    createdAt: "2025-03-10T07:00:00Z", updatedAt: "2025-03-20T08:00:00Z",
  },
  {
    id: "BATCH-TUR-2025-003", qrCode: "QR-TUR-003-2025", species: "Curcuma longa", commonName: "Turmeric",
    productName: "Organic Turmeric Curcumin", status: "testing",
    collectionEvents: [{
      ...ashwagandhaCollection, id: "CE-003", batchId: "BATCH-TUR-2025-003", species: "Curcuma longa", commonName: "Turmeric",
      collectorName: "Suresh Patel", cooperativeName: "Madhya Pradesh Wild Collectors",
      latitude: 22.601, longitude: 75.305, altitude: 520, timestamp: "2025-03-22T06:00:00Z",
      harvestMethod: "cultivated", initialWeight: 200.0, sustainabilityScore: 95,
    }],
    qualityTests: [],
    processingSteps: [],
    finalWeight: 0, sustainabilityScore: 95, fairTradeVerified: false,
    createdAt: "2025-03-22T06:00:00Z", updatedAt: "2025-03-22T06:00:00Z",
  },
  {
    id: "BATCH-AMI-2025-004", qrCode: "QR-AMI-004-2025", species: "Phyllanthus emblica", commonName: "Amla",
    productName: "Amla Vitamin C Tablets", status: "formulated",
    collectionEvents: [{
      ...ashwagandhaCollection, id: "CE-004", batchId: "BATCH-AMI-2025-004", species: "Phyllanthus emblica", commonName: "Amla",
      collectorName: "Kavita Singh", cooperativeName: "Rajasthan Farmers Cooperative",
      latitude: 27.198, longitude: 73.185, altitude: 295, timestamp: "2025-02-28T07:30:00Z",
      harvestMethod: "cultivated", initialWeight: 300.0, sustainabilityScore: 90, qualityGrade: "A",
    }],
    qualityTests: [{ ...ashwagandhaQuality, id: "QT-004", batchId: "BATCH-AMI-2025-004", testDate: "2025-03-03T10:00:00Z" }],
    processingSteps: ashwagandhaProcessing.slice(0, 3).map((s, i) => ({ ...s, id: `PS-004-${i}`, batchId: "BATCH-AMI-2025-004" })),
    finalWeight: 100.0, sustainabilityScore: 90, fairTradeVerified: true,
    createdAt: "2025-02-28T07:30:00Z", updatedAt: "2025-03-25T16:00:00Z",
  },
];

export const dashboardMetrics: DashboardMetrics = {
  totalBatches: 47,
  activeBatches: 12,
  totalTransactions: 1834,
  networkNodes: 8,
  avgSustainabilityScore: 89.5,
  qualityPassRate: 96.2,
  speciesTracked: 23,
  consumerScans: 3421,
};

export const monthlyData = [
  { month: "Oct", batches: 5, scans: 180, transactions: 120 },
  { month: "Nov", batches: 7, scans: 290, transactions: 185 },
  { month: "Dec", batches: 4, scans: 210, transactions: 95 },
  { month: "Jan", batches: 8, scans: 450, transactions: 230 },
  { month: "Feb", batches: 11, scans: 620, transactions: 310 },
  { month: "Mar", batches: 12, scans: 810, transactions: 394 },
];

export const speciesDistribution = [
  { name: "Ashwagandha", value: 28, fill: "hsl(145, 45%, 28%)" },
  { name: "Tulsi", value: 18, fill: "hsl(145, 35%, 45%)" },
  { name: "Turmeric", value: 22, fill: "hsl(38, 55%, 55%)" },
  { name: "Amla", value: 15, fill: "hsl(28, 60%, 50%)" },
  { name: "Brahmi", value: 10, fill: "hsl(25, 30%, 35%)" },
  { name: "Others", value: 7, fill: "hsl(150, 10%, 45%)" },
];
