export interface CollectionEvent {
  id: string;
  batchId: string;
  species: string;
  commonName: string;
  collectorId: string;
  collectorName: string;
  cooperativeName: string;
  latitude: number;
  longitude: number;
  altitude: number;
  timestamp: string;
  harvestMethod: "wild-collection" | "cultivated";
  soilMoisture: number;
  ambientTemp: number;
  humidity: number;
  initialWeight: number;
  qualityGrade: "A" | "B" | "C";
  geoFenceApproved: boolean;
  seasonalApproved: boolean;
  sustainabilityScore: number;
  blockHash: string;
  txHash: string;
}

export interface QualityTest {
  id: string;
  batchId: string;
  labId: string;
  labName: string;
  testDate: string;
  moistureContent: number;
  moisturePass: boolean;
  pesticideLevel: number;
  pesticidePass: boolean;
  heavyMetals: number;
  heavyMetalsPass: boolean;
  dnaBarcodeMatch: boolean;
  microbialCount: number;
  microbialPass: boolean;
  aflatoxinLevel: number;
  aflatoxinPass: boolean;
  overallPass: boolean;
  certificateUrl: string;
  blockHash: string;
  txHash: string;
}

export interface ProcessingStep {
  id: string;
  batchId: string;
  facilityId: string;
  facilityName: string;
  stepType: "drying" | "grinding" | "extraction" | "blending" | "packaging";
  startTime: string;
  endTime: string;
  temperature: number;
  humidity: number;
  inputWeight: number;
  outputWeight: number;
  operatorId: string;
  notes: string;
  blockHash: string;
  txHash: string;
}

export interface Batch {
  id: string;
  qrCode: string;
  species: string;
  commonName: string;
  productName: string;
  status: "harvested" | "testing" | "processing" | "formulated" | "dispatched" | "retail";
  collectionEvents: CollectionEvent[];
  qualityTests: QualityTest[];
  processingSteps: ProcessingStep[];
  finalWeight: number;
  sustainabilityScore: number;
  fairTradeVerified: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface NetworkNode {
  id: string;
  name: string;
  type: "cooperative" | "collector" | "lab" | "processor" | "manufacturer" | "retailer";
  location: string;
  latitude: number;
  longitude: number;
  isActive: boolean;
  transactionCount: number;
}

export interface DashboardMetrics {
  totalBatches: number;
  activeBatches: number;
  totalTransactions: number;
  networkNodes: number;
  avgSustainabilityScore: number;
  qualityPassRate: number;
  speciesTracked: number;
  consumerScans: number;
}
