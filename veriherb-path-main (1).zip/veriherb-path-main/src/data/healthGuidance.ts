export interface HealthCondition {
  id: string;
  condition: string;
  category: "respiratory" | "digestive" | "skin" | "immunity" | "pain" | "mental" | "womens-health" | "general";
  symptoms: string[];
  herbRemedies: {
    herbId: string;
    herbName: string;
    preparation: string;
    dosage: string;
    duration: string;
  }[];
  lifestyleChanges: string[];
  whenToSeeDoctor: string;
  disclaimer: string;
}

export const healthConditions: HealthCondition[] = [
  {
    id: "cold-cough",
    condition: "Cold & Cough",
    category: "respiratory",
    symptoms: ["Runny nose", "Sneezing", "Sore throat", "Cough", "Mild body ache"],
    herbRemedies: [
      { herbId: "tulsi", herbName: "Tulsi", preparation: "Boil 10–15 tulsi leaves with 1 inch ginger, 5 black pepper corns in 2 cups water. Reduce to 1 cup. Add honey and lemon.", dosage: "1 cup, 2–3 times daily", duration: "5–7 days" },
      { herbId: "turmeric", herbName: "Turmeric", preparation: "Add 1 tsp turmeric to hot milk with a pinch of black pepper and honey (golden milk).", dosage: "1 cup at bedtime", duration: "Until symptoms resolve" },
      { herbId: "ginger", herbName: "Ginger", preparation: "Slice fresh ginger, boil in water for 10 min. Add honey and lemon juice.", dosage: "3 cups daily", duration: "5 days" },
    ],
    lifestyleChanges: [
      "Rest adequately — aim for 8+ hours of sleep",
      "Stay hydrated — drink warm water throughout the day",
      "Steam inhalation with eucalyptus oil for 10 minutes twice daily",
      "Avoid cold foods and drinks; eat warm, easily digestible meals",
      "Gargle with warm salt water 3 times daily",
      "Keep the room well-ventilated but avoid cold drafts",
    ],
    whenToSeeDoctor: "If fever exceeds 102°F, symptoms persist beyond 10 days, or you experience difficulty breathing.",
    disclaimer: "This guidance is for informational purposes only. These are traditional Ayurvedic remedies and not a substitute for professional medical advice."
  },
  {
    id: "fever",
    condition: "Fever",
    category: "general",
    symptoms: ["Elevated temperature", "Chills", "Sweating", "Body ache", "Weakness"],
    herbRemedies: [
      { herbId: "tulsi", herbName: "Tulsi", preparation: "Make kadha: Boil tulsi leaves, black pepper, cinnamon, and cardamom in water for 15 min.", dosage: "Every 4–6 hours", duration: "Until fever subsides" },
      { herbId: "ginger", herbName: "Ginger", preparation: "Ginger tea with honey and lemon. Add a pinch of cinnamon.", dosage: "3–4 times daily", duration: "3–5 days" },
      { herbId: "neem", herbName: "Neem", preparation: "Boil 10 neem leaves in water, cool, and drink the decoction.", dosage: "Twice daily in small quantities", duration: "3 days maximum" },
    ],
    lifestyleChanges: [
      "Complete bed rest until fever subsides",
      "Drink plenty of fluids — water, coconut water, herbal teas",
      "Eat light foods: khichdi, dal rice, soups",
      "Use wet cloth compress on forehead for comfort",
      "Wear light, breathable cotton clothing",
      "Avoid heavy, oily, or spicy foods",
    ],
    whenToSeeDoctor: "If fever exceeds 103°F, lasts more than 3 days, or is accompanied by severe headache, rash, or stiff neck.",
    disclaimer: "This guidance is for informational purposes only. Fever can indicate serious infections. Always consult a doctor for persistent or high fever."
  },
  {
    id: "indigestion",
    condition: "Indigestion & Bloating",
    category: "digestive",
    symptoms: ["Stomach discomfort", "Bloating", "Gas", "Acidity", "Nausea"],
    herbRemedies: [
      { herbId: "mint", herbName: "Mint", preparation: "Brew 8–10 fresh mint leaves in hot water for 5 min. Add a squeeze of lemon.", dosage: "After each meal", duration: "As needed" },
      { herbId: "ginger", herbName: "Ginger", preparation: "Grate 1 inch fresh ginger, squeeze juice, mix with lemon juice and a pinch of rock salt.", dosage: "Before meals", duration: "1–2 weeks" },
      { herbId: "coriander", herbName: "Coriander", preparation: "Soak 1 tbsp coriander seeds in water overnight. Strain and drink on empty stomach.", dosage: "Every morning", duration: "2 weeks" },
      { herbId: "fenugreek", herbName: "Fenugreek", preparation: "Soak 1 tsp fenugreek seeds overnight. Chew the seeds and drink the water.", dosage: "Morning on empty stomach", duration: "2 weeks" },
    ],
    lifestyleChanges: [
      "Eat slowly and chew food thoroughly — at least 20 chews per bite",
      "Avoid lying down immediately after meals — wait 2 hours",
      "Have dinner at least 3 hours before bedtime",
      "Walk for 10–15 minutes after meals (shatapavali)",
      "Avoid mixing fruit with meals",
      "Reduce caffeine and carbonated drinks",
      "Practice vajrasana (sitting on heels) for 5 min after meals",
    ],
    whenToSeeDoctor: "If symptoms persist for more than 2 weeks, if you notice blood in stools, or experience unexplained weight loss.",
    disclaimer: "This guidance is for informational purposes only and not a substitute for professional medical diagnosis."
  },
  {
    id: "skin-issues",
    condition: "Skin Problems (Acne, Rashes, Infections)",
    category: "skin",
    symptoms: ["Acne", "Rashes", "Itching", "Dryness", "Fungal infections"],
    herbRemedies: [
      { herbId: "neem", herbName: "Neem", preparation: "Make neem paste: Grind fresh neem leaves with water. Apply to affected area for 20 min, then rinse.", dosage: "Once daily", duration: "2–3 weeks" },
      { herbId: "aloe-vera", herbName: "Aloe Vera", preparation: "Extract fresh gel from aloe leaf. Apply directly on skin. Leave for 30 min or overnight.", dosage: "2 times daily", duration: "4 weeks" },
      { herbId: "turmeric", herbName: "Turmeric", preparation: "Mix 1 tsp turmeric with 2 tsp gram flour and rose water. Apply as face mask for 15 min.", dosage: "3 times per week", duration: "4 weeks" },
    ],
    lifestyleChanges: [
      "Drink at least 8 glasses of water daily",
      "Eat fresh fruits and vegetables rich in vitamins A and C",
      "Avoid processed foods, excessive sugar, and dairy (if acne-prone)",
      "Change pillowcases twice a week",
      "Use gentle, natural cleansers — avoid harsh chemical soaps",
      "Get 7–8 hours of sleep for skin repair",
      "Manage stress through yoga and meditation",
    ],
    whenToSeeDoctor: "If skin infection spreads, is painful, oozes pus, or doesn't improve within 3 weeks of home treatment.",
    disclaimer: "This guidance is for informational purposes only. Skin conditions may require dermatological evaluation."
  },
  {
    id: "stress-anxiety",
    condition: "Stress & Anxiety",
    category: "mental",
    symptoms: ["Restlessness", "Irritability", "Poor sleep", "Racing thoughts", "Muscle tension"],
    herbRemedies: [
      { herbId: "ashwagandha", herbName: "Ashwagandha", preparation: "Mix 1 tsp ashwagandha powder in warm milk with a pinch of nutmeg and honey.", dosage: "300–500mg, twice daily", duration: "6–8 weeks for full benefits" },
      { herbId: "tulsi", herbName: "Tulsi", preparation: "Brew tulsi tea: 5–6 fresh leaves in hot water for 5 min. Add honey.", dosage: "2–3 cups daily", duration: "Ongoing" },
      { herbId: "mint", herbName: "Mint", preparation: "Peppermint tea with chamomile. Inhale deeply while drinking.", dosage: "Evening relaxation ritual", duration: "Ongoing" },
    ],
    lifestyleChanges: [
      "Practice pranayama (breathing exercises) — start with 10 min daily",
      "Daily meditation — even 5 minutes makes a difference",
      "Regular physical exercise — 30 min walking, yoga, or swimming",
      "Reduce screen time 1 hour before bed",
      "Maintain a consistent sleep schedule",
      "Limit caffeine intake, especially after 2 PM",
      "Journal your thoughts for 5 min before bed",
      "Spend time in nature — forest bathing (shinrin-yoku)",
    ],
    whenToSeeDoctor: "If anxiety significantly impacts daily functioning, you experience panic attacks, or have thoughts of self-harm.",
    disclaimer: "This guidance supports mental wellness but is not a substitute for professional mental health care."
  },
  {
    id: "hair-loss",
    condition: "Hair Loss & Dandruff",
    category: "general",
    symptoms: ["Excessive hair fall", "Thinning hair", "Dandruff", "Dry scalp", "Itchy scalp"],
    herbRemedies: [
      { herbId: "curry-leaves", herbName: "Curry Leaves", preparation: "Boil curry leaves in coconut oil until leaves turn black. Cool, strain, and massage into scalp.", dosage: "2–3 times per week", duration: "2–3 months" },
      { herbId: "amla", herbName: "Amla", preparation: "Mix amla powder with coconut oil and fenugreek powder. Apply to scalp for 30 min before wash.", dosage: "2 times per week", duration: "3 months" },
      { herbId: "rosemary", herbName: "Rosemary", preparation: "Steep rosemary sprigs in warm olive oil for 2 hours. Massage warm oil into scalp.", dosage: "2 times per week", duration: "2–3 months" },
      { herbId: "neem", herbName: "Neem", preparation: "Boil neem leaves, cool the water, and use as final hair rinse after shampooing.", dosage: "Every wash day", duration: "Ongoing" },
    ],
    lifestyleChanges: [
      "Eat protein-rich foods: lentils, eggs, nuts, and seeds",
      "Include iron and zinc in your diet: spinach, pumpkin seeds",
      "Avoid excessive heat styling and tight hairstyles",
      "Use a wide-toothed comb on wet hair",
      "Manage stress — it's a major cause of hair loss",
      "Stay hydrated and get adequate sleep",
    ],
    whenToSeeDoctor: "If hair loss is sudden, patchy, or accompanied by other symptoms like fatigue or weight changes.",
    disclaimer: "This guidance is for informational purposes only. Hair loss may indicate underlying health conditions."
  },
  {
    id: "diabetes-support",
    condition: "Blood Sugar Management",
    category: "general",
    symptoms: ["Elevated blood sugar", "Frequent urination", "Excessive thirst", "Fatigue"],
    herbRemedies: [
      { herbId: "fenugreek", herbName: "Fenugreek", preparation: "Soak 1 tbsp methi seeds in water overnight. Eat the seeds and drink the water on empty stomach.", dosage: "Daily morning", duration: "Ongoing with monitoring" },
      { herbId: "curry-leaves", herbName: "Curry Leaves", preparation: "Eat 8–10 fresh curry leaves on empty stomach every morning.", dosage: "Daily", duration: "Ongoing" },
      { herbId: "aloe-vera", herbName: "Aloe Vera", preparation: "Drink 2 tbsp pure aloe vera juice (latex-free) mixed in water before breakfast.", dosage: "Once daily", duration: "2–3 months, then reassess" },
    ],
    lifestyleChanges: [
      "Walk for 30–45 minutes daily, preferably after meals",
      "Eat small, frequent meals instead of large meals",
      "Choose complex carbs: whole grains, millets, brown rice",
      "Include bitter gourd, jamun, and fenugreek in diet regularly",
      "Monitor blood sugar levels regularly",
      "Reduce refined sugar, white bread, and processed foods",
      "Practice stress management — stress raises blood sugar",
    ],
    whenToSeeDoctor: "Always manage diabetes under medical supervision. These remedies are supportive, not replacements for prescribed medication.",
    disclaimer: "IMPORTANT: Never replace diabetes medication with herbal remedies without consulting your doctor. These are complementary approaches only."
  },
];
