import { useState } from "react";
import { motion } from "framer-motion";
import { Upload, Leaf, Plus, Trash2, CheckCircle2, Package, Thermometer, Droplets, MapPin, User, Calendar } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { QRCodeSVG } from "qrcode.react";
import { useToast } from "@/hooks/use-toast";

interface HerbUpload {
  id: string;
  herbName: string;
  scientificName: string;
  farmerName: string;
  farmLocation: string;
  latitude: string;
  longitude: string;
  harvestDate: string;
  harvestMethod: string;
  quantity: string;
  qualityGrade: string;
  soilType: string;
  irrigationMethod: string;
  fertilizerUsed: string;
  pesticideUsed: string;
  altitude: string;
  temperature: string;
  humidity: string;
  dryingMethod: string;
  storageMethod: string;
  packagingType: string;
  transportMode: string;
  batchNotes: string;
  qrCode: string;
  uploadedAt: string;
}

const initialForm = {
  herbName: "",
  scientificName: "",
  farmerName: "",
  farmLocation: "",
  latitude: "",
  longitude: "",
  harvestDate: "",
  harvestMethod: "",
  quantity: "",
  qualityGrade: "",
  soilType: "",
  irrigationMethod: "",
  fertilizerUsed: "",
  pesticideUsed: "",
  altitude: "",
  temperature: "",
  humidity: "",
  dryingMethod: "",
  storageMethod: "",
  packagingType: "",
  transportMode: "",
  batchNotes: "",
};

export default function FarmerUploadPage() {
  const [form, setForm] = useState(initialForm);
  const [uploads, setUploads] = useState<HerbUpload[]>([]);
  const [showForm, setShowForm] = useState(false);
  const { toast } = useToast();

  const set = (field: string, value: string) => setForm(f => ({ ...f, [field]: value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.herbName || !form.farmerName || !form.harvestDate || !form.quantity) {
      toast({ title: "Missing fields", description: "Please fill herb name, farmer name, harvest date, and quantity.", variant: "destructive" });
      return;
    }
    const id = `FARM-${Date.now().toString(36).toUpperCase()}`;
    const qrCode = `QR-FARM-${form.herbName.replace(/\s+/g, "").toUpperCase().slice(0, 4)}-${id.slice(-4)}`;
    const upload: HerbUpload = { ...form, id, qrCode, uploadedAt: new Date().toISOString() };
    setUploads(prev => [upload, ...prev]);
    setForm(initialForm);
    setShowForm(false);
    toast({ title: "Herb details uploaded!", description: `QR Code: ${qrCode} generated for ${form.herbName}` });
  };

  return (
    <div className="min-h-screen bg-background pt-20 pb-12">
      <div className="container mx-auto px-4 max-w-5xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
          <div className="w-20 h-20 rounded-full gradient-leaf mx-auto flex items-center justify-center mb-5">
            <Upload className="w-10 h-10 text-primary-foreground" />
          </div>
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">Farmer Herb Upload</h1>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Upload details of your manufactured herbs. A unique QR code is generated for each entry for traceability.
          </p>
        </motion.div>

        {!showForm && (
          <div className="text-center mb-8">
            <Button onClick={() => setShowForm(true)} className="gradient-leaf text-primary-foreground px-8 py-3">
              <Plus className="w-5 h-5 mr-2" /> Upload New Herb
            </Button>
          </div>
        )}

        {showForm && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Card className="shadow-elevated mb-8">
              <CardHeader>
                <CardTitle className="font-display flex items-center gap-2">
                  <Leaf className="w-5 h-5 text-primary" /> Herb Manufacturing Details
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Basic Info */}
                  <div>
                    <h3 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
                      <Leaf className="w-4 h-4 text-primary" /> Herb Information
                    </h3>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div><Label>Herb Common Name *</Label><Input value={form.herbName} onChange={e => set("herbName", e.target.value)} placeholder="e.g. Ashwagandha" /></div>
                      <div><Label>Scientific Name</Label><Input value={form.scientificName} onChange={e => set("scientificName", e.target.value)} placeholder="e.g. Withania somnifera" /></div>
                      <div>
                        <Label>Quality Grade</Label>
                        <Select value={form.qualityGrade} onValueChange={v => set("qualityGrade", v)}>
                          <SelectTrigger><SelectValue placeholder="Select grade" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="A">Grade A (Premium)</SelectItem>
                            <SelectItem value="B">Grade B (Standard)</SelectItem>
                            <SelectItem value="C">Grade C (Economy)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div><Label>Quantity (kg) *</Label><Input type="number" value={form.quantity} onChange={e => set("quantity", e.target.value)} placeholder="e.g. 150" /></div>
                    </div>
                  </div>

                  {/* Farmer Info */}
                  <div>
                    <h3 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
                      <User className="w-4 h-4 text-primary" /> Farmer Details
                    </h3>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div><Label>Farmer Name *</Label><Input value={form.farmerName} onChange={e => set("farmerName", e.target.value)} placeholder="e.g. Ramesh Sharma" /></div>
                      <div><Label>Farm Location</Label><Input value={form.farmLocation} onChange={e => set("farmLocation", e.target.value)} placeholder="e.g. Nagaur, Rajasthan" /></div>
                      <div><Label>Latitude</Label><Input value={form.latitude} onChange={e => set("latitude", e.target.value)} placeholder="e.g. 27.2015" /></div>
                      <div><Label>Longitude</Label><Input value={form.longitude} onChange={e => set("longitude", e.target.value)} placeholder="e.g. 73.1822" /></div>
                    </div>
                  </div>

                  {/* Harvest Info */}
                  <div>
                    <h3 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
                      <Calendar className="w-4 h-4 text-primary" /> Harvest & Growing
                    </h3>
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      <div><Label>Harvest Date *</Label><Input type="date" value={form.harvestDate} onChange={e => set("harvestDate", e.target.value)} /></div>
                      <div>
                        <Label>Harvest Method</Label>
                        <Select value={form.harvestMethod} onValueChange={v => set("harvestMethod", v)}>
                          <SelectTrigger><SelectValue placeholder="Select method" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="wild-collection">Wild Collection</SelectItem>
                            <SelectItem value="cultivated">Cultivated</SelectItem>
                            <SelectItem value="organic-farm">Organic Farm</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div><Label>Soil Type</Label><Input value={form.soilType} onChange={e => set("soilType", e.target.value)} placeholder="e.g. Red loamy" /></div>
                      <div><Label>Irrigation Method</Label><Input value={form.irrigationMethod} onChange={e => set("irrigationMethod", e.target.value)} placeholder="e.g. Drip irrigation" /></div>
                      <div><Label>Fertilizer Used</Label><Input value={form.fertilizerUsed} onChange={e => set("fertilizerUsed", e.target.value)} placeholder="e.g. Organic compost" /></div>
                      <div><Label>Pesticide Used</Label><Input value={form.pesticideUsed} onChange={e => set("pesticideUsed", e.target.value)} placeholder="e.g. None / Neem-based" /></div>
                    </div>
                  </div>

                  {/* Environment */}
                  <div>
                    <h3 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
                      <Thermometer className="w-4 h-4 text-primary" /> Environmental Conditions
                    </h3>
                    <div className="grid sm:grid-cols-3 gap-4">
                      <div><Label>Altitude (m)</Label><Input value={form.altitude} onChange={e => set("altitude", e.target.value)} placeholder="e.g. 310" /></div>
                      <div><Label>Temperature (°C)</Label><Input value={form.temperature} onChange={e => set("temperature", e.target.value)} placeholder="e.g. 28" /></div>
                      <div><Label>Humidity (%)</Label><Input value={form.humidity} onChange={e => set("humidity", e.target.value)} placeholder="e.g. 45" /></div>
                    </div>
                  </div>

                  {/* Post-Harvest */}
                  <div>
                    <h3 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
                      <Package className="w-4 h-4 text-primary" /> Post-Harvest & Transport
                    </h3>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <Label>Drying Method</Label>
                        <Select value={form.dryingMethod} onValueChange={v => set("dryingMethod", v)}>
                          <SelectTrigger><SelectValue placeholder="Select method" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="sun-dried">Sun Dried</SelectItem>
                            <SelectItem value="shade-dried">Shade Dried</SelectItem>
                            <SelectItem value="machine-dried">Machine Dried</SelectItem>
                            <SelectItem value="freeze-dried">Freeze Dried</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div><Label>Storage Method</Label><Input value={form.storageMethod} onChange={e => set("storageMethod", e.target.value)} placeholder="e.g. Airtight jute bags" /></div>
                      <div><Label>Packaging Type</Label><Input value={form.packagingType} onChange={e => set("packagingType", e.target.value)} placeholder="e.g. Vacuum-sealed pouches" /></div>
                      <div>
                        <Label>Transport Mode</Label>
                        <Select value={form.transportMode} onValueChange={v => set("transportMode", v)}>
                          <SelectTrigger><SelectValue placeholder="Select mode" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="road">Road (Truck)</SelectItem>
                            <SelectItem value="rail">Rail</SelectItem>
                            <SelectItem value="air">Air Freight</SelectItem>
                            <SelectItem value="local">Local Cart/Vehicle</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label>Additional Notes</Label>
                    <Textarea value={form.batchNotes} onChange={e => set("batchNotes", e.target.value)} placeholder="Any special notes about this batch..." rows={3} />
                  </div>

                  <div className="flex gap-3">
                    <Button type="submit" className="gradient-leaf text-primary-foreground px-8">
                      <Upload className="w-4 h-4 mr-2" /> Submit & Generate QR
                    </Button>
                    <Button type="button" variant="outline" onClick={() => { setShowForm(false); setForm(initialForm); }}>Cancel</Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Uploaded Herbs List */}
        {uploads.length > 0 && (
          <div>
            <h2 className="font-display text-xl font-bold text-foreground mb-4">Uploaded Herbs ({uploads.length})</h2>
            <div className="grid md:grid-cols-2 gap-4">
              {uploads.map(u => (
                <motion.div key={u.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                  <Card className="shadow-card hover:shadow-elevated transition-shadow">
                    <CardContent className="p-5">
                      <div className="flex gap-4">
                        <div className="bg-white p-2 rounded-lg border border-border">
                          <QRCodeSVG value={u.qrCode} size={80} />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="font-display font-semibold text-foreground">{u.herbName}</h3>
                              {u.scientificName && <p className="text-xs text-muted-foreground italic">{u.scientificName}</p>}
                            </div>
                            {u.qualityGrade && <Badge className="bg-primary/10 text-primary">Grade {u.qualityGrade}</Badge>}
                          </div>
                          <div className="grid grid-cols-2 gap-x-4 gap-y-1 mt-2 text-xs">
                            <p className="text-muted-foreground"><span className="text-foreground font-medium">Farmer:</span> {u.farmerName}</p>
                            <p className="text-muted-foreground"><span className="text-foreground font-medium">Qty:</span> {u.quantity} kg</p>
                            <p className="text-muted-foreground"><span className="text-foreground font-medium">Date:</span> {new Date(u.harvestDate).toLocaleDateString()}</p>
                            <p className="text-muted-foreground"><span className="text-foreground font-medium">Location:</span> {u.farmLocation || "N/A"}</p>
                          </div>
                          <p className="text-xs font-mono text-primary mt-2">QR: {u.qrCode}</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="mt-2 text-destructive hover:text-destructive" onClick={() => setUploads(prev => prev.filter(x => x.id !== u.id))}>
                        <Trash2 className="w-3 h-3 mr-1" /> Remove
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Sample entries info */}
        {uploads.length === 0 && !showForm && (
          <Card className="shadow-card text-center p-10">
            <Package className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-foreground font-medium">No herbs uploaded yet</p>
            <p className="text-sm text-muted-foreground">Click "Upload New Herb" to add your first herb manufacturing details</p>
          </Card>
        )}
      </div>
    </div>
  );
}
