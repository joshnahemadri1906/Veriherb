import { useState } from "react";
import { motion } from "framer-motion";
import { Leaf, Mail, Lock, User, Eye, EyeOff, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<"consumer" | "farmer" | "processor" | "lab">("consumer");
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || (!isLogin && !name)) {
      toast({ title: "Missing fields", description: "Please fill in all required fields.", variant: "destructive" });
      return;
    }
    // Store user info in localStorage for demo
    localStorage.setItem("vanasetu_user", JSON.stringify({ name: isLogin ? "User" : name, email, role }));
    toast({ title: isLogin ? "Welcome back!" : "Account created!", description: `Logged in as ${role}` });
    navigate(role === "farmer" ? "/alerts" : "/dashboard");
  };

  return (
    <div className="min-h-screen gradient-hero flex items-center justify-center px-4 py-12">
      <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-full gradient-leaf mx-auto flex items-center justify-center mb-4">
            <Leaf className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="font-display text-3xl font-bold text-cream">VanaSetu</h1>
          <p className="text-cream/60 mt-1">Blockchain Traceability for Ayurvedic Herbs</p>
        </div>

        <Card className="shadow-elevated">
          <CardContent className="p-6">
            {/* Toggle */}
            <div className="flex rounded-lg bg-muted p-1 mb-6">
              <button onClick={() => setIsLogin(true)}
                className={`flex-1 py-2 text-sm font-medium rounded-md transition-colors ${isLogin ? "bg-background text-foreground shadow-sm" : "text-muted-foreground"}`}>
                Sign In
              </button>
              <button onClick={() => setIsLogin(false)}
                className={`flex-1 py-2 text-sm font-medium rounded-md transition-colors ${!isLogin ? "bg-background text-foreground shadow-sm" : "text-muted-foreground"}`}>
                Sign Up
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <div className="relative">
                  <User className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                  <Input value={name} onChange={e => setName(e.target.value)} placeholder="Full Name" className="pl-10" />
                </div>
              )}
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email address" className="pl-10" />
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input type={showPassword ? "text" : "password"} value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" className="pl-10 pr-10" />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-3 text-muted-foreground hover:text-foreground">
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {!isLogin && (
                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">I am a:</label>
                  <div className="grid grid-cols-2 gap-2">
                    {(["consumer", "farmer", "processor", "lab"] as const).map(r => (
                      <button key={r} type="button" onClick={() => setRole(r)}
                        className={`py-2 px-3 rounded-md text-sm font-medium border transition-colors capitalize ${
                          role === r ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-primary/50"
                        }`}>{r === "lab" ? "Lab Technician" : r}</button>
                    ))}
                  </div>
                </div>
              )}

              <Button type="submit" className="w-full gradient-leaf text-primary-foreground">
                {isLogin ? "Sign In" : "Create Account"} <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </form>

            {isLogin && (
              <p className="text-center text-sm text-muted-foreground mt-4">
                <button className="text-primary hover:underline">Forgot password?</button>
              </p>
            )}
          </CardContent>
        </Card>

        <p className="text-center text-cream/40 text-xs mt-6">
          Demo mode — no real authentication. All data is simulated.
        </p>
      </motion.div>
    </div>
  );
}
