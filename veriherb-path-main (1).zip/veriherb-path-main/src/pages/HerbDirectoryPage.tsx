import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, MapPin, Truck, Package, AlertTriangle, Heart, Leaf, ChevronDown, ChevronUp, FlaskConical, ShieldAlert, Ban, Info } from "lucide-react";
import { herbDatabase, getHerbsByRegion, indianRegions, HerbInfo } from "@/data/herbDatabase";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

function HerbCard({ herb }: { herb: HerbInfo }) {
  const [expanded, setExpanded] = useState(false);
  const [activeSection, setActiveSection] = useState<string>("overview");

  const sections = [
    { key: "overview", label: "Overview", icon: Leaf },
    { key: "transport", label: "Transport & Storage", icon: Truck },
    { key: "safety", label: "Safety & Warnings", icon: ShieldAlert },
    { key: "remedies", label: "Remedies", icon: Heart },
  ];

  return (
    <Card className="shadow-card overflow-hidden">
      {/* Header */}
      <div className="p-4 cursor-pointer" onClick={() => setExpanded(!expanded)} style={{ borderLeft: `4px solid ${herb.imageColor}` }}>
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-display text-lg font-semibold text-foreground">{herb.commonName}</h3>
            <p className="text-sm text-primary italic">{herb.scientificName}</p>
            <div className="flex flex-wrap gap-1 mt-2">
              {herb.region.slice(0, 3).map(r => (
                <Badge key={r} variant="secondary" className="text-xs"><MapPin className="w-3 h-3 mr-1" />{r}</Badge>
              ))}
              {herb.region.length > 3 && <Badge variant="secondary" className="text-xs">+{herb.region.length - 3} more</Badge>}
            </div>
          </div>
          {expanded ? <ChevronUp className="w-5 h-5 text-muted-foreground" /> : <ChevronDown className="w-5 h-5 text-muted-foreground" />}
        </div>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}>
            {/* Section tabs */}
            <div className="flex border-t border-b border-border">
              {sections.map(s => (
                <button key={s.key} onClick={() => setActiveSection(s.key)}
                  className={`flex items-center gap-1 px-3 py-2 text-xs font-medium flex-1 justify-center transition-colors ${
                    activeSection === s.key ? "text-primary border-b-2 border-primary" : "text-muted-foreground hover:text-foreground"
                  }`}>
                  <s.icon className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{s.label}</span>
                </button>
              ))}
            </div>

            <CardContent className="p-4">
              {activeSection === "overview" && (
                <div className="space-y-3 text-sm">
                  <div>
                    <p className="font-medium text-foreground mb-1">Uses</p>
                    <p className="text-muted-foreground">{herb.uses}</p>
                  </div>
                  <div>
                    <p className="font-medium text-foreground mb-1">Benefits</p>
                    <p className="text-muted-foreground">{herb.benefits}</p>
                  </div>
                  <div className="grid sm:grid-cols-3 gap-3 p-3 rounded-lg bg-muted/50">
                    <div>
                      <p className="text-xs text-muted-foreground">Appearance</p>
                      <p className="text-foreground text-xs mt-1">{herb.appearance}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Smell</p>
                      <p className="text-foreground text-xs mt-1">{herb.smell}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Consistency</p>
                      <p className="text-foreground text-xs mt-1">{herb.consistency}</p>
                    </div>
                  </div>
                  {herb.aliases.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      <span className="text-xs text-muted-foreground">Also known as:</span>
                      {herb.aliases.map(a => <Badge key={a} variant="outline" className="text-xs">{a}</Badge>)}
                    </div>
                  )}
                </div>
              )}

              {activeSection === "transport" && (
                <div className="space-y-4 text-sm">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Truck className="w-4 h-4 text-primary" />
                      <h4 className="font-medium text-foreground">Transport Information</h4>
                    </div>
                    <div className="grid sm:grid-cols-2 gap-2">
                      {Object.entries(herb.transport).map(([key, val]) => (
                        <div key={key} className="p-2 rounded bg-muted/50">
                          <span className="text-xs text-muted-foreground capitalize">{key.replace(/([A-Z])/g, ' $1')}: </span>
                          <span className="text-xs text-foreground">{val}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Package className="w-4 h-4 text-primary" />
                      <h4 className="font-medium text-foreground">Storage Information</h4>
                    </div>
                    <div className="grid sm:grid-cols-2 gap-2">
                      {Object.entries(herb.storage).map(([key, val]) => (
                        <div key={key} className="p-2 rounded bg-muted/50">
                          <span className="text-xs text-muted-foreground capitalize">{key.replace(/([A-Z])/g, ' $1')}: </span>
                          <span className="text-xs text-foreground">{val}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeSection === "safety" && (
                <div className="space-y-3 text-sm">
                  {herb.allergies.length > 0 && (
                    <div className="p-3 rounded-lg border border-destructive/20 bg-destructive/5">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle className="w-4 h-4 text-destructive" />
                        <span className="font-medium text-destructive">Allergy Warnings</span>
                      </div>
                      <ul className="space-y-1">
                        {herb.allergies.map((a, i) => <li key={i} className="text-muted-foreground text-xs">• {a}</li>)}
                      </ul>
                    </div>
                  )}
                  {herb.contraindications.length > 0 && (
                    <div className="p-3 rounded-lg border border-saffron/20 bg-saffron/5">
                      <div className="flex items-center gap-2 mb-2">
                        <Ban className="w-4 h-4 text-saffron" />
                        <span className="font-medium text-saffron">Contraindications</span>
                      </div>
                      <ul className="space-y-1">
                        {herb.contraindications.map((c, i) => <li key={i} className="text-muted-foreground text-xs">• {c}</li>)}
                      </ul>
                    </div>
                  )}
                  {herb.doNotUseWith.length > 0 && (
                    <div className="p-3 rounded-lg border border-destructive/20 bg-destructive/5">
                      <div className="flex items-center gap-2 mb-2">
                        <ShieldAlert className="w-4 h-4 text-destructive" />
                        <span className="font-medium text-destructive">Do NOT Use With</span>
                      </div>
                      <ul className="space-y-1">
                        {herb.doNotUseWith.map((d, i) => <li key={i} className="text-muted-foreground text-xs">• {d}</li>)}
                      </ul>
                    </div>
                  )}
                  {herb.disadvantages.length > 0 && (
                    <div className="p-3 rounded-lg border border-border bg-muted/30">
                      <div className="flex items-center gap-2 mb-2">
                        <Info className="w-4 h-4 text-muted-foreground" />
                        <span className="font-medium text-foreground">Disadvantages</span>
                      </div>
                      <ul className="space-y-1">
                        {herb.disadvantages.map((d, i) => <li key={i} className="text-muted-foreground text-xs">• {d}</li>)}
                      </ul>
                    </div>
                  )}
                </div>
              )}

              {activeSection === "remedies" && (
                <div className="space-y-3 text-sm">
                  {herb.remedies.map((r, i) => (
                    <div key={i} className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-primary">{r.condition}</p>
                      <p className="text-muted-foreground mt-1">{r.preparation}</p>
                      <p className="text-xs text-foreground mt-1">Dosage: {r.dosage}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}

export default function HerbDirectoryPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRegion, setSelectedRegion] = useState("");

  const filtered = herbDatabase.filter(h => {
    const matchesSearch = !searchQuery || 
      h.commonName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.scientificName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.aliases.some(a => a.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesRegion = !selectedRegion || 
      h.region.some(r => r.toLowerCase().includes(selectedRegion.toLowerCase())) ||
      h.region.includes("All of India");
    return matchesSearch && matchesRegion;
  });

  return (
    <div className="min-h-screen bg-background pt-20 pb-12">
      <div className="container mx-auto px-4 max-w-5xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">Herb Directory</h1>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Explore our complete database of Ayurvedic herbs with transport, storage, safety, and remedy information
          </p>
        </motion.div>

        {/* Filters */}
        <Card className="shadow-card mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search herbs by name..." className="pl-10" />
              </div>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <select value={selectedRegion} onChange={e => setSelectedRegion(e.target.value)}
                  className="h-10 pl-10 pr-8 rounded-md border border-input bg-background text-sm text-foreground w-full sm:w-56 appearance-none">
                  <option value="">All Regions</option>
                  {indianRegions.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        <p className="text-sm text-muted-foreground mb-4">{filtered.length} herbs found</p>

        <div className="space-y-4">
          {filtered.map(herb => <HerbCard key={herb.id} herb={herb} />)}
        </div>

        {filtered.length === 0 && (
          <Card className="text-center p-10 shadow-card">
            <Leaf className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-foreground font-medium">No herbs found</p>
            <p className="text-sm text-muted-foreground">Try a different search term or region</p>
          </Card>
        )}
      </div>
    </div>
  );
}
