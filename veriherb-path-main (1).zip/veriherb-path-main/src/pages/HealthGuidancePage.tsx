import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Heart, Stethoscope, Leaf, ChevronDown, ChevronUp, AlertCircle, Activity, Sparkles, UserRound, Send, X } from "lucide-react";
import { healthConditions, HealthCondition } from "@/data/healthGuidance";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

interface PersonalizedResult {
  age: number;
  matchedConditions: HealthCondition[];
  ageNotes: string[];
  dietaryTips: string[];
  summary: string;
}

function getAgeGroup(age: number): string {
  if (age < 12) return "child";
  if (age < 18) return "teen";
  if (age < 45) return "adult";
  if (age < 65) return "middle-aged";
  return "senior";
}

function generatePersonalizedGuidance(age: number, problem: string, symptoms: string): PersonalizedResult | null {
  const input = `${problem} ${symptoms}`.toLowerCase();
  const ageGroup = getAgeGroup(age);

  const matched = healthConditions.filter(c => {
    const condMatch = c.condition.toLowerCase().split(/\s+/).some(w => input.includes(w));
    const symptomMatch = c.symptoms.some(s => input.includes(s.toLowerCase()));
    const categoryMatch = input.includes(c.category);
    return condMatch || symptomMatch || categoryMatch;
  });

  if (matched.length === 0) return null;

  const ageNotes: string[] = [];
  const dietaryTips: string[] = [];

  if (ageGroup === "child") {
    ageNotes.push("For children under 12, use half the recommended dosage for all herbal remedies.");
    ageNotes.push("Avoid neem and ashwagandha for children without medical supervision.");
    ageNotes.push("Ensure remedies are mild — prefer honey-based preparations.");
    dietaryTips.push("Include warm milk with turmeric (small pinch) before bedtime.");
    dietaryTips.push("Offer fresh fruit juices and light soups for hydration.");
  } else if (ageGroup === "teen") {
    ageNotes.push("Teenagers can use standard dosages but should start with lower amounts.");
    ageNotes.push("Focus on stress management techniques — exam pressure can worsen symptoms.");
    dietaryTips.push("Maintain a balanced diet rich in iron and calcium for growth.");
    dietaryTips.push("Limit junk food and sugary drinks which can aggravate many conditions.");
  } else if (ageGroup === "adult") {
    ageNotes.push("Standard dosages apply. Consistency is key for herbal remedies.");
    dietaryTips.push("Stay hydrated — aim for 2.5–3 liters of water daily.");
    dietaryTips.push("Include seasonal fruits and green vegetables in every meal.");
  } else if (ageGroup === "middle-aged") {
    ageNotes.push("Check for drug interactions if you are on any regular medication.");
    ageNotes.push("Focus on joint health, digestion, and stress management.");
    dietaryTips.push("Reduce salt and sugar intake. Prefer millets over refined grains.");
    dietaryTips.push("Include anti-inflammatory foods: turmeric, ginger, garlic daily.");
  } else {
    ageNotes.push("Seniors should use reduced dosages (about 60–75% of standard).");
    ageNotes.push("Consult your doctor before starting any new herbal remedy, especially if on blood thinners or heart medication.");
    ageNotes.push("Avoid strong decoctions — prefer milder teas and infusions.");
    dietaryTips.push("Eat warm, soft, easily digestible meals. Avoid raw or cold foods.");
    dietaryTips.push("Include soaked almonds, warm milk, and ghee in moderate quantities.");
  }

  const summary = `Based on your age (${age}, ${ageGroup}) and described symptoms, we found ${matched.length} matching condition(s). Below are personalized Ayurvedic remedies with age-appropriate dosage guidance.`;

  return { age, matchedConditions: matched, ageNotes, dietaryTips, summary };
}

function PersonalizedResultCard({ result }: { result: PersonalizedResult }) {
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
      {/* Summary */}
      <Card className="shadow-card border-primary/20 bg-primary/5">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <UserRound className="w-5 h-5 text-primary mt-0.5" />
            <div>
              <h3 className="font-display font-semibold text-foreground mb-1">Your Personalized Assessment</h3>
              <p className="text-sm text-muted-foreground">{result.summary}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Age-Specific Notes */}
      <Card className="shadow-card">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <AlertCircle className="w-4 h-4 text-primary" />
            <h4 className="font-medium text-foreground">Age-Specific Guidance (Age {result.age})</h4>
          </div>
          <ul className="space-y-1.5">
            {result.ageNotes.map((n, i) => (
              <li key={i} className="text-sm text-muted-foreground flex gap-2">
                <span className="text-primary mt-0.5">⚕️</span> {n}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Dietary Tips */}
      <Card className="shadow-card">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4 text-primary" />
            <h4 className="font-medium text-foreground">Dietary Recommendations</h4>
          </div>
          <ul className="space-y-1.5">
            {result.dietaryTips.map((t, i) => (
              <li key={i} className="text-sm text-muted-foreground flex gap-2">
                <span className="text-primary mt-0.5">🍃</span> {t}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Matched Conditions with full details */}
      {result.matchedConditions.map(c => (
        <ConditionCard key={c.id} condition={c} defaultExpanded />
      ))}
    </motion.div>
  );
}

function ConditionCard({ condition, defaultExpanded = false }: { condition: HealthCondition; defaultExpanded?: boolean }) {
  const [expanded, setExpanded] = useState(defaultExpanded);

  const categoryColors: Record<string, string> = {
    respiratory: "bg-blue-100 text-blue-700",
    digestive: "bg-amber-100 text-amber-700",
    skin: "bg-pink-100 text-pink-700",
    immunity: "bg-green-100 text-green-700",
    pain: "bg-red-100 text-red-700",
    mental: "bg-purple-100 text-purple-700",
    "womens-health": "bg-rose-100 text-rose-700",
    general: "bg-slate-100 text-slate-700",
  };

  return (
    <Card className="shadow-card overflow-hidden">
      <div className="p-4 cursor-pointer" onClick={() => setExpanded(!expanded)}>
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-display text-lg font-semibold text-foreground">{condition.condition}</h3>
              <Badge className={`text-xs ${categoryColors[condition.category] || categoryColors.general}`}>{condition.category}</Badge>
            </div>
            <div className="flex flex-wrap gap-1 mt-2">
              {condition.symptoms.slice(0, 4).map(s => (
                <Badge key={s} variant="outline" className="text-xs">{s}</Badge>
              ))}
            </div>
          </div>
          {expanded ? <ChevronUp className="w-5 h-5 text-muted-foreground" /> : <ChevronDown className="w-5 h-5 text-muted-foreground" />}
        </div>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}>
            <CardContent className="p-4 pt-0 space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Leaf className="w-4 h-4 text-primary" />
                  <h4 className="font-medium text-foreground">Natural Herb Remedies</h4>
                </div>
                <div className="space-y-3">
                  {condition.herbRemedies.map((r, i) => (
                    <div key={i} className="p-3 rounded-lg bg-primary/5 border border-primary/10">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-primary text-sm">{r.herbName}</span>
                        <Badge variant="secondary" className="text-xs">{r.duration}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{r.preparation}</p>
                      <p className="text-xs text-foreground font-medium">Dosage: {r.dosage}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Sparkles className="w-4 h-4 text-turmeric" />
                  <h4 className="font-medium text-foreground">Lifestyle Changes</h4>
                </div>
                <ul className="space-y-1.5">
                  {condition.lifestyleChanges.map((lc, i) => (
                    <li key={i} className="text-sm text-muted-foreground flex gap-2">
                      <span className="text-primary mt-0.5">✦</span> {lc}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-3 rounded-lg border border-destructive/20 bg-destructive/5">
                <div className="flex items-center gap-2 mb-1">
                  <Stethoscope className="w-4 h-4 text-destructive" />
                  <span className="font-medium text-destructive text-sm">When to See a Doctor</span>
                </div>
                <p className="text-xs text-muted-foreground">{condition.whenToSeeDoctor}</p>
              </div>

              <div className="p-3 rounded-lg bg-muted/50">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-muted-foreground mt-0.5" />
                  <p className="text-xs text-muted-foreground italic">{condition.disclaimer}</p>
                </div>
              </div>
            </CardContent>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}

export default function HealthGuidancePage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [showConsultation, setShowConsultation] = useState(false);
  const [age, setAge] = useState("");
  const [problem, setProblem] = useState("");
  const [symptoms, setSymptoms] = useState("");
  const [personalizedResult, setPersonalizedResult] = useState<PersonalizedResult | null>(null);
  const [noMatch, setNoMatch] = useState(false);

  const categories = ["respiratory", "digestive", "skin", "immunity", "pain", "mental", "womens-health", "general"];

  const filtered = healthConditions.filter(c => {
    const matchesSearch = !searchQuery ||
      c.condition.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.symptoms.some(s => s.toLowerCase().includes(searchQuery.toLowerCase())) ||
      c.herbRemedies.some(r => r.herbName.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = !selectedCategory || c.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleConsult = () => {
    const ageNum = parseInt(age);
    if (!ageNum || ageNum < 1 || ageNum > 120 || !problem.trim()) return;
    const result = generatePersonalizedGuidance(ageNum, problem, symptoms);
    if (result) {
      setPersonalizedResult(result);
      setNoMatch(false);
    } else {
      setPersonalizedResult(null);
      setNoMatch(true);
    }
  };

  const clearConsultation = () => {
    setShowConsultation(false);
    setAge("");
    setProblem("");
    setSymptoms("");
    setPersonalizedResult(null);
    setNoMatch(false);
  };

  return (
    <div className="min-h-screen bg-background pt-20 pb-12">
      <div className="container mx-auto px-4 max-w-4xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
          <div className="w-16 h-16 rounded-full gradient-gold mx-auto flex items-center justify-center mb-4">
            <Activity className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">Health Guidance</h1>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Tell us your symptoms and we'll guide you with natural Ayurvedic remedies, preparation methods, and lifestyle changes
          </p>
        </motion.div>

        {/* Detailed Consultation Toggle */}
        <Card className="shadow-card mb-6 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <UserRound className="w-5 h-5 text-primary" />
                <h3 className="font-display font-semibold text-foreground">Describe Your Issue in Detail</h3>
              </div>
              {showConsultation ? (
                <Button variant="ghost" size="sm" onClick={clearConsultation}><X className="w-4 h-4" /></Button>
              ) : (
                <Button variant="outline" size="sm" onClick={() => setShowConsultation(true)}>Get Personalized Guidance</Button>
              )}
            </div>

            <AnimatePresence>
              {showConsultation && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs font-medium text-muted-foreground mb-1 block">Your Age</label>
                      <Input type="number" min={1} max={120} value={age} onChange={e => setAge(e.target.value)} placeholder="e.g. 28" />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="text-xs font-medium text-muted-foreground mb-1 block">Main Problem</label>
                      <Input value={problem} onChange={e => setProblem(e.target.value)} placeholder="e.g. I have cold and cough for 3 days" />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1 block">Describe Your Symptoms</label>
                    <Textarea value={symptoms} onChange={e => setSymptoms(e.target.value)}
                      placeholder="e.g. runny nose, sore throat, mild fever, body ache, sneezing, feeling weak..."
                      className="min-h-[80px]" />
                  </div>
                  <Button onClick={handleConsult} className="w-full" disabled={!age || !problem.trim()}>
                    <Send className="w-4 h-4 mr-2" /> Get Personalized Guidance
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>

        {/* Personalized Results */}
        {personalizedResult && <PersonalizedResultCard result={personalizedResult} />}

        {noMatch && (
          <Card className="text-center p-8 shadow-card mb-6 border-destructive/20">
            <Heart className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-foreground font-medium">No matching conditions found for your description</p>
            <p className="text-sm text-muted-foreground mt-1">Try describing different symptoms or browse the conditions below</p>
          </Card>
        )}

        {/* Divider when personalized results shown */}
        {personalizedResult && (
          <div className="my-8 flex items-center gap-3">
            <div className="flex-1 h-px bg-border" />
            <span className="text-xs text-muted-foreground font-medium">Browse All Conditions</span>
            <div className="flex-1 h-px bg-border" />
          </div>
        )}

        {/* Search */}
        <Card className="shadow-card mb-6">
          <CardContent className="p-4">
            <div className="relative mb-3">
              <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
              <Input value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
                placeholder="Describe your issue: cold, cough, fever, stress, skin problem..."
                className="pl-10" />
            </div>
            <div className="flex flex-wrap gap-2">
              <button onClick={() => setSelectedCategory("")}
                className={`text-xs px-3 py-1 rounded-full transition-colors ${!selectedCategory ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"}`}>
                All
              </button>
              {categories.map(cat => (
                <button key={cat} onClick={() => setSelectedCategory(cat)}
                  className={`text-xs px-3 py-1 rounded-full transition-colors capitalize ${selectedCategory === cat ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"}`}>
                  {cat.replace("-", " ")}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          {filtered.map(c => <ConditionCard key={c.id} condition={c} />)}
        </div>

        {filtered.length === 0 && (
          <Card className="text-center p-10 shadow-card">
            <Heart className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-foreground font-medium">No matching conditions found</p>
            <p className="text-sm text-muted-foreground">Try different symptoms or browse all categories</p>
          </Card>
        )}

        <div className="mt-8 p-4 rounded-lg border border-primary/20 bg-primary/5 text-center">
          <p className="text-sm text-muted-foreground">
            ⚕️ <strong className="text-foreground">Disclaimer:</strong> This guidance is based on traditional Ayurvedic knowledge and is for informational purposes only. 
            Always consult a qualified healthcare professional before starting any herbal treatment, especially if you are on medication, pregnant, or nursing.
          </p>
        </div>
      </div>
    </div>
  );
}