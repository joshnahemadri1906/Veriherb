import { motion } from "framer-motion";
import { MapPin, ThermometerSun, Droplets, Wind, CheckCircle2, XCircle, Leaf } from "lucide-react";
import { batches } from "@/data/mockData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useEffect, useRef } from "react";

export default function CollectionPage() {
  const allEvents = batches.flatMap(b => b.collectionEvents);
  const mapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!mapRef.current) return;
    const loadMap = async () => {
      const L = await import("leaflet");
      await import("leaflet/dist/leaflet.css");

      const existing = (mapRef.current as any)?._leaflet_id;
      if (existing) return;

      const map = L.map(mapRef.current!, { scrollWheelZoom: false }).setView([22, 78], 5);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '© OpenStreetMap',
      }).addTo(map);

      allEvents.forEach(e => {
        L.circleMarker([e.latitude, e.longitude], {
          radius: 8, fillColor: "hsl(145,45%,28%)", color: "hsl(38,55%,55%)", weight: 2, fillOpacity: 0.8,
        }).addTo(map).bindPopup(`<b>${e.commonName}</b><br/>${e.collectorName}<br/>${e.cooperativeName}`);
      });
    };
    loadMap();
  }, []);

  return (
    <div className="min-h-screen bg-background pt-20 pb-12">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">Geo-Tagged Collection Events</h1>
          <p className="text-muted-foreground mb-8">GPS-verified harvest data recorded on the blockchain</p>
        </motion.div>

        {/* Map */}
        <Card className="shadow-card mb-8">
          <CardContent className="p-0">
            <div ref={mapRef} className="h-[400px] rounded-xl" />
          </CardContent>
        </Card>

        {/* Events */}
        <div className="grid md:grid-cols-2 gap-6">
          {allEvents.map((e, i) => (
            <motion.div key={e.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
              <Card className="shadow-card overflow-hidden">
                <div className="gradient-leaf p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-display text-xl font-bold text-primary-foreground">{e.commonName}</h3>
                      <p className="text-primary-foreground/70 text-sm italic">{e.species}</p>
                    </div>
                    <Badge className="bg-primary-foreground/20 text-primary-foreground">{e.qualityGrade}</Badge>
                  </div>
                </div>
                <CardContent className="p-5 space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-primary" />
                      <span className="text-muted-foreground">{e.latitude.toFixed(4)}°N, {e.longitude.toFixed(4)}°E</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Leaf className="w-4 h-4 text-primary" />
                      <span className="text-muted-foreground">{e.harvestMethod}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <ThermometerSun className="w-4 h-4 text-turmeric" />
                      <span className="text-muted-foreground">{e.ambientTemp}°C</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Droplets className="w-4 h-4 text-turmeric" />
                      <span className="text-muted-foreground">{e.humidity}% humidity</span>
                    </div>
                  </div>

                  <div className="border-t border-border pt-4">
                    <p className="text-sm text-foreground"><strong>Collector:</strong> {e.collectorName}</p>
                    <p className="text-sm text-muted-foreground">{e.cooperativeName}</p>
                    <p className="text-sm text-muted-foreground">Weight: {e.initialWeight} kg • Alt: {e.altitude}m</p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <div className="flex items-center gap-1 text-xs">
                      {e.geoFenceApproved ? <CheckCircle2 className="w-3.5 h-3.5 text-primary" /> : <XCircle className="w-3.5 h-3.5 text-destructive" />}
                      <span className="text-muted-foreground">Geo-fence</span>
                    </div>
                    <div className="flex items-center gap-1 text-xs">
                      {e.seasonalApproved ? <CheckCircle2 className="w-3.5 h-3.5 text-primary" /> : <XCircle className="w-3.5 h-3.5 text-destructive" />}
                      <span className="text-muted-foreground">Seasonal</span>
                    </div>
                    <Badge variant="outline" className="text-xs">Sustainability: {e.sustainabilityScore}%</Badge>
                  </div>

                  <div className="text-xs text-muted-foreground font-mono bg-muted/50 p-2 rounded">
                    TX: {e.txHash.slice(0, 20)}...
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
