import { motion } from "framer-motion";
import { CheckCircle2, XCircle, FileCheck, Beaker } from "lucide-react";
import { batches } from "@/data/mockData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function QualityPage() {
  const allTests = batches.flatMap(b => b.qualityTests);

  const TestRow = ({ label, value, unit, pass }: { label: string; value: number; unit: string; pass: boolean }) => (
    <div className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
      <span className="text-sm text-muted-foreground">{label}</span>
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-foreground">{value} {unit}</span>
        {pass ? <CheckCircle2 className="w-4 h-4 text-primary" /> : <XCircle className="w-4 h-4 text-destructive" />}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background pt-20 pb-12">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">Quality Test Results</h1>
          <p className="text-muted-foreground mb-8">Laboratory certifications recorded on the immutable ledger</p>
        </motion.div>

        {/* Summary */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card className="shadow-card">
            <CardContent className="p-5 text-center">
              <Beaker className="w-8 h-8 text-primary mx-auto mb-2" />
              <p className="text-3xl font-bold text-foreground">{allTests.length}</p>
              <p className="text-sm text-muted-foreground">Tests Completed</p>
            </CardContent>
          </Card>
          <Card className="shadow-card">
            <CardContent className="p-5 text-center">
              <CheckCircle2 className="w-8 h-8 text-primary mx-auto mb-2" />
              <p className="text-3xl font-bold text-foreground">{allTests.filter(t => t.overallPass).length}</p>
              <p className="text-sm text-muted-foreground">Passed</p>
            </CardContent>
          </Card>
          <Card className="shadow-card">
            <CardContent className="p-5 text-center">
              <FileCheck className="w-8 h-8 text-turmeric mx-auto mb-2" />
              <p className="text-3xl font-bold text-foreground">{allTests.filter(t => t.dnaBarcodeMatch).length}</p>
              <p className="text-sm text-muted-foreground">DNA Verified</p>
            </CardContent>
          </Card>
        </div>

        {/* Test details */}
        <div className="space-y-6">
          {allTests.map((t, i) => (
            <motion.div key={t.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
              <Card className="shadow-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="font-display">{t.labName}</CardTitle>
                      <p className="text-sm text-muted-foreground">Batch: {t.batchId} • {new Date(t.testDate).toLocaleDateString()}</p>
                    </div>
                    <Badge className={t.overallPass ? "bg-primary/20 text-primary" : "bg-destructive/20 text-destructive"}>
                      {t.overallPass ? "PASSED" : "FAILED"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <TestRow label="Moisture Content" value={t.moistureContent} unit="%" pass={t.moisturePass} />
                      <TestRow label="Pesticide Level" value={t.pesticideLevel} unit="ppm" pass={t.pesticidePass} />
                      <TestRow label="Heavy Metals" value={t.heavyMetals} unit="ppm" pass={t.heavyMetalsPass} />
                    </div>
                    <div>
                      <TestRow label="Microbial Count" value={t.microbialCount} unit="CFU/g" pass={t.microbialPass} />
                      <TestRow label="Aflatoxin Level" value={t.aflatoxinLevel} unit="ppb" pass={t.aflatoxinPass} />
                      <div className="flex items-center justify-between py-2">
                        <span className="text-sm text-muted-foreground">DNA Barcode Match</span>
                        {t.dnaBarcodeMatch ? <CheckCircle2 className="w-4 h-4 text-primary" /> : <XCircle className="w-4 h-4 text-destructive" />}
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 text-xs text-muted-foreground font-mono bg-muted/50 p-2 rounded">
                    TX: {t.txHash.slice(0, 30)}...
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
