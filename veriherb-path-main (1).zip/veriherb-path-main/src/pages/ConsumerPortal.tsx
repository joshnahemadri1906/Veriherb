import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { QrCode, Search, MapPin, FlaskConical, Cog, Shield, Leaf, CheckCircle2, Package, Truck, AlertTriangle, Ban, Info, HelpCircle, Camera, X } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { batches } from "@/data/mockData";
import { findHerbByName, herbDatabase, HerbInfo } from "@/data/herbDatabase";
import { Batch } from "@/data/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Html5Qrcode } from "html5-qrcode";

function HerbIdentificationQuiz({ possibleHerbs, onIdentified }: { possibleHerbs: HerbInfo[]; onIdentified: (herb: HerbInfo) => void }) {
  const [step, setStep] = useState(0);
  const [remaining, setRemaining] = useState(possibleHerbs);

  const questions = [
    { question: "What does the herb smell like?", getAnswer: (h: HerbInfo) => h.smell },
    { question: "Describe the appearance:", getAnswer: (h: HerbInfo) => h.appearance },
    { question: "What is the consistency/texture?", getAnswer: (h: HerbInfo) => h.consistency },
  ];

  if (remaining.length <= 1) {
    if (remaining.length === 1) onIdentified(remaining[0]);
    return null;
  }

  const q = questions[step];
  if (!q) {
    onIdentified(remaining[0]);
    return null;
  }

  return (
    <Card className="shadow-card border-2 border-turmeric/30 mb-4">
      <CardContent className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <HelpCircle className="w-5 h-5 text-turmeric" />
          <h3 className="font-display font-semibold text-foreground">Multiple herbs match — help us identify</h3>
        </div>
        <p className="text-sm text-muted-foreground mb-3">{q.question}</p>
        <div className="space-y-2">
          {remaining.map(herb => (
            <button key={herb.id} onClick={() => { setRemaining([herb]); onIdentified(herb); }}
              className="w-full text-left p-3 rounded-lg border border-border hover:border-primary transition-colors">
              <p className="font-medium text-foreground text-sm">{herb.commonName}</p>
              <p className="text-xs text-muted-foreground mt-1">{q.getAnswer(herb)}</p>
            </button>
          ))}
        </div>
        {step < questions.length - 1 && (
          <button onClick={() => setStep(s => s + 1)} className="text-sm text-primary hover:underline mt-3">
            Skip this question →
          </button>
        )}
      </CardContent>
    </Card>
  );
}

function HerbDetailPanel({ herb }: { herb: HerbInfo }) {
  const [tab, setTab] = useState<"info" | "transport" | "safety">("info");

  return (
    <Card className="shadow-card mb-4">
      <CardHeader className="pb-2">
        <CardTitle className="font-display text-lg flex items-center gap-2">
          <Leaf className="w-5 h-5 text-primary" />
          {herb.commonName} — <span className="text-primary italic font-normal text-base">{herb.scientificName}</span>
        </CardTitle>
      </CardHeader>
      <div className="flex border-b border-border">
        {[
          { key: "info" as const, label: "Details" },
          { key: "transport" as const, label: "Transport & Storage" },
          { key: "safety" as const, label: "Safety" },
        ].map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`px-4 py-2 text-sm font-medium flex-1 text-center transition-colors ${
              tab === t.key ? "text-primary border-b-2 border-primary" : "text-muted-foreground"
            }`}>{t.label}</button>
        ))}
      </div>
      <CardContent className="p-4 text-sm">
        {tab === "info" && (
          <div className="space-y-3">
            <p className="text-muted-foreground"><strong className="text-foreground">Uses:</strong> {herb.uses}</p>
            <p className="text-muted-foreground"><strong className="text-foreground">Benefits:</strong> {herb.benefits}</p>
            <div className="grid sm:grid-cols-3 gap-2 p-3 rounded-lg bg-muted/50">
              <div><span className="text-xs text-muted-foreground">Appearance:</span><p className="text-xs text-foreground mt-1">{herb.appearance}</p></div>
              <div><span className="text-xs text-muted-foreground">Smell:</span><p className="text-xs text-foreground mt-1">{herb.smell}</p></div>
              <div><span className="text-xs text-muted-foreground">Consistency:</span><p className="text-xs text-foreground mt-1">{herb.consistency}</p></div>
            </div>
            {herb.remedies.length > 0 && (
              <div>
                <p className="font-medium text-foreground mb-2">Home Remedies</p>
                {herb.remedies.map((r, i) => (
                  <div key={i} className="p-2 rounded bg-primary/5 mb-1">
                    <span className="text-primary font-medium text-xs">{r.condition}:</span>
                    <span className="text-muted-foreground text-xs ml-1">{r.preparation} ({r.dosage})</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        {tab === "transport" && (
          <div className="space-y-4">
            <div>
              <div className="flex items-center gap-2 mb-2"><Truck className="w-4 h-4 text-primary" /><h4 className="font-medium text-foreground">Transport</h4></div>
              <div className="grid sm:grid-cols-2 gap-2">
                {Object.entries(herb.transport).map(([k, v]) => (
                  <div key={k} className="p-2 rounded bg-muted/50">
                    <span className="text-xs text-muted-foreground capitalize">{k.replace(/([A-Z])/g, ' $1')}: </span>
                    <span className="text-xs text-foreground">{v}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2"><Package className="w-4 h-4 text-primary" /><h4 className="font-medium text-foreground">Storage</h4></div>
              <div className="grid sm:grid-cols-2 gap-2">
                {Object.entries(herb.storage).map(([k, v]) => (
                  <div key={k} className="p-2 rounded bg-muted/50">
                    <span className="text-xs text-muted-foreground capitalize">{k.replace(/([A-Z])/g, ' $1')}: </span>
                    <span className="text-xs text-foreground">{v}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
        {tab === "safety" && (
          <div className="space-y-3">
            {herb.allergies.length > 0 && (
              <div className="p-3 rounded-lg border border-destructive/20 bg-destructive/5">
                <div className="flex items-center gap-2 mb-1"><AlertTriangle className="w-4 h-4 text-destructive" /><span className="font-medium text-destructive text-sm">Allergy Warnings</span></div>
                {herb.allergies.map((a, i) => <p key={i} className="text-xs text-muted-foreground">• {a}</p>)}
              </div>
            )}
            {herb.contraindications.length > 0 && (
              <div className="p-3 rounded-lg border border-saffron/20 bg-saffron/5">
                <div className="flex items-center gap-2 mb-1"><Ban className="w-4 h-4 text-saffron" /><span className="font-medium text-saffron text-sm">Contraindications</span></div>
                {herb.contraindications.map((c, i) => <p key={i} className="text-xs text-muted-foreground">• {c}</p>)}
              </div>
            )}
            {herb.doNotUseWith.length > 0 && (
              <div className="p-3 rounded-lg border border-destructive/20 bg-destructive/5">
                <div className="flex items-center gap-2 mb-1"><Shield className="w-4 h-4 text-destructive" /><span className="font-medium text-destructive text-sm">Do NOT Use With</span></div>
                {herb.doNotUseWith.map((d, i) => <p key={i} className="text-xs text-muted-foreground">• {d}</p>)}
              </div>
            )}
            {herb.disadvantages.length > 0 && (
              <div className="p-3 rounded-lg border border-border bg-muted/30">
                <div className="flex items-center gap-2 mb-1"><Info className="w-4 h-4 text-muted-foreground" /><span className="font-medium text-foreground text-sm">Disadvantages</span></div>
                {herb.disadvantages.map((d, i) => <p key={i} className="text-xs text-muted-foreground">• {d}</p>)}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function QrScanner({ onScan, onClose }: { onScan: (text: string) => void; onClose: () => void }) {
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let isRunning = false;
    let cancelled = false;
    const scanner = new Html5Qrcode("qr-reader");
    scannerRef.current = scanner;

    scanner.start(
      { facingMode: "environment" },
      { fps: 10, qrbox: { width: 250, height: 250 } },
      (decodedText) => {
        if (!isRunning) return;
        isRunning = false;
        scanner.stop().then(() => {
          if (!cancelled) onScan(decodedText);
        }).catch(() => {});
      },
      () => {}
    ).then(() => {
      isRunning = true;
    }).catch((err) => {
      console.error("Camera error:", err);
    });

    return () => {
      cancelled = true;
      if (isRunning) {
        isRunning = false;
        scanner.stop().catch(() => {});
      }
    };
  }, [onScan]);

  return (
    <Card className="shadow-card mb-6 overflow-hidden">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-display font-semibold text-foreground flex items-center gap-2">
            <Camera className="w-5 h-5 text-primary" /> Camera Scanner
          </h3>
          <Button variant="ghost" size="icon" onClick={onClose}><X className="w-4 h-4" /></Button>
        </div>
        <div id="qr-reader" className="w-full rounded-lg overflow-hidden" />
        <p className="text-xs text-muted-foreground text-center mt-2">Point your camera at a QR code on the herb product</p>
      </CardContent>
    </Card>
  );
}

export default function ConsumerPortal() {
  const [query, setQuery] = useState("");
  const [scannedBatch, setScannedBatch] = useState<Batch | null>(null);
  const [identifiedHerb, setIdentifiedHerb] = useState<HerbInfo | null>(null);
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizHerbs, setQuizHerbs] = useState<HerbInfo[]>([]);
  const [activeTab, setActiveTab] = useState<"origin" | "quality" | "processing" | "sustainability">("origin");
  const [showScanner, setShowScanner] = useState(false);

  const handleSearch = (q: string) => {
    const lower = q.toLowerCase().trim();
    if (!lower) return;

    setQuery(q);

    // Try batch first
    const found = batches.find(b =>
      b.qrCode.toLowerCase().includes(lower) ||
      b.id.toLowerCase().includes(lower) ||
      b.commonName.toLowerCase().includes(lower) ||
      b.productName.toLowerCase().includes(lower) ||
      b.species.toLowerCase().includes(lower)
    );
    setScannedBatch(found || null);

    // Also try herb identification
    const herb = findHerbByName(lower);
    if (herb) {
      const similar = herbDatabase.filter((h: HerbInfo) =>
        h.id !== herb.id && (
          herb.similarHerbs.includes(h.id) ||
          h.similarHerbs.includes(herb.id) ||
          h.commonName.toLowerCase().includes(lower) ||
          h.scientificName.toLowerCase().includes(lower)
        )
      );
      if (similar.length > 0) {
        setQuizHerbs([herb, ...similar]);
        setShowQuiz(true);
        setIdentifiedHerb(null);
      } else {
        setIdentifiedHerb(herb);
        setShowQuiz(false);
      }
    } else {
      setIdentifiedHerb(null);
      setShowQuiz(false);
    }
  };

  const handleScan = () => handleSearch(query);

  const quickScan = (batch: Batch) => {
    setQuery(batch.qrCode);
    setScannedBatch(batch);
    const herb = findHerbByName(batch.commonName);
    setIdentifiedHerb(herb || null);
    setShowQuiz(false);
  };

  const handleQrScan = (text: string) => {
    setShowScanner(false);
    handleSearch(text);
  };

  const tabs = [
    { key: "origin" as const, label: "Origin", icon: MapPin },
    { key: "quality" as const, label: "Lab Results", icon: FlaskConical },
    { key: "processing" as const, label: "Processing", icon: Cog },
    { key: "sustainability" as const, label: "Sustainability", icon: Leaf },
  ];

  return (
    <div className="min-h-screen bg-background pt-20 pb-12">
      <div className="container mx-auto px-4 max-w-4xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-10">
          <div className="w-20 h-20 rounded-full gradient-leaf mx-auto flex items-center justify-center mb-5">
            <QrCode className="w-10 h-10 text-primary-foreground" />
          </div>
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">Verify Your Product</h1>
          <p className="text-muted-foreground max-w-md mx-auto">
            Scan the QR code on your product, enter the code, or search by herb name to view complete details
          </p>
        </motion.div>

        {/* Search */}
        <Card className="shadow-card mb-6">
          <CardContent className="p-5">
            <div className="flex gap-3">
              <Input value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => e.key === "Enter" && handleScan()}
                placeholder="Enter QR code, batch ID, or herb name (e.g. Ashwagandha, Tulsi)"
                className="flex-1" />
              <Button onClick={handleScan} className="gradient-leaf text-primary-foreground">
                <Search className="w-4 h-4 mr-2" /> Verify
              </Button>
              <Button onClick={() => setShowScanner(s => !s)} variant="outline" className="border-primary text-primary hover:bg-primary/10">
                <Camera className="w-4 h-4 mr-2" /> Scan
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-3">
              <span className="text-xs text-muted-foreground">Try:</span>
              {batches.filter(b => b.qualityTests.length > 0).map(b => (
                <button key={b.id} onClick={() => quickScan(b)}
                  className="text-xs text-primary hover:underline cursor-pointer">{b.qrCode}</button>
              ))}
              {["Ginger", "Neem", "Mint", "Coriander"].map(name => (
                <button key={name} onClick={() => { handleSearch(name); }}
                  className="text-xs text-turmeric hover:underline cursor-pointer">{name}</button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Camera Scanner */}
        {showScanner && (
          <QrScanner onScan={handleQrScan} onClose={() => setShowScanner(false)} />
        )}
        {showQuiz && quizHerbs.length > 1 && (
          <HerbIdentificationQuiz possibleHerbs={quizHerbs} onIdentified={(herb) => { setIdentifiedHerb(herb); setShowQuiz(false); }} />
        )}

        {/* Identified Herb Details */}
        {identifiedHerb && !showQuiz && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <HerbDetailPanel herb={identifiedHerb} />
          </motion.div>
        )}

        {/* Batch Results */}
        <AnimatePresence mode="wait">
          {scannedBatch && (
            <motion.div key={scannedBatch.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {/* Product header */}
              <Card className="shadow-elevated mb-6 overflow-hidden">
                <div className="gradient-hero p-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <CheckCircle2 className="w-5 h-5 text-turmeric" />
                        <span className="text-turmeric text-sm font-medium">Blockchain Verified</span>
                      </div>
                      <h2 className="font-display text-2xl font-bold text-cream">{scannedBatch.productName}</h2>
                      <p className="text-cream/60 italic">{scannedBatch.species}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-cream/60 text-xs">Batch</p>
                      <p className="text-cream font-mono text-sm">{scannedBatch.id}</p>
                    </div>
                  </div>
                </div>

                {/* Tabs */}
                <div className="flex border-b border-border">
                  {tabs.map(tab => (
                    <button key={tab.key} onClick={() => setActiveTab(tab.key)}
                      className={`flex items-center gap-1.5 px-4 py-3 text-sm font-medium transition-colors flex-1 justify-center ${
                        activeTab === tab.key ? "text-primary border-b-2 border-primary" : "text-muted-foreground hover:text-foreground"
                      }`}>
                      <tab.icon className="w-4 h-4" />
                      <span className="hidden sm:inline">{tab.label}</span>
                    </button>
                  ))}
                </div>

                <CardContent className="p-6">
                  {activeTab === "origin" && scannedBatch.collectionEvents[0] && (() => {
                    const e = scannedBatch.collectionEvents[0];
                    return (
                      <div className="space-y-4">
                        <h3 className="font-display text-lg font-semibold text-foreground">Harvest Origin</h3>
                        <div className="grid sm:grid-cols-2 gap-4 text-sm">
                          <div><span className="text-muted-foreground">Collector:</span> <span className="text-foreground font-medium">{e.collectorName}</span></div>
                          <div><span className="text-muted-foreground">Cooperative:</span> <span className="text-foreground font-medium">{e.cooperativeName}</span></div>
                          <div><span className="text-muted-foreground">Coordinates:</span> <span className="text-foreground font-mono">{e.latitude.toFixed(4)}°N, {e.longitude.toFixed(4)}°E</span></div>
                          <div><span className="text-muted-foreground">Altitude:</span> <span className="text-foreground">{e.altitude}m</span></div>
                          <div><span className="text-muted-foreground">Harvest Date:</span> <span className="text-foreground">{new Date(e.timestamp).toLocaleDateString()}</span></div>
                          <div><span className="text-muted-foreground">Method:</span> <span className="text-foreground capitalize">{e.harvestMethod}</span></div>
                          <div><span className="text-muted-foreground">Temperature:</span> <span className="text-foreground">{e.ambientTemp}°C</span></div>
                          <div><span className="text-muted-foreground">Weight:</span> <span className="text-foreground">{e.initialWeight} kg</span></div>
                        </div>
                        <div className="flex gap-2">
                          {e.geoFenceApproved && <Badge className="bg-primary/10 text-primary">✓ Geo-Fence Approved</Badge>}
                          {e.seasonalApproved && <Badge className="bg-primary/10 text-primary">✓ Seasonal Approved</Badge>}
                        </div>
                      </div>
                    );
                  })()}

                  {activeTab === "quality" && (
                    <div className="space-y-4">
                      <h3 className="font-display text-lg font-semibold text-foreground">Laboratory Certificates</h3>
                      {scannedBatch.qualityTests.length > 0 ? scannedBatch.qualityTests.map(t => (
                        <div key={t.id} className="space-y-3">
                          <p className="text-sm text-muted-foreground">{t.labName} • {new Date(t.testDate).toLocaleDateString()}</p>
                          <div className="grid grid-cols-2 gap-3 text-sm">
                            {[
                              { label: "Moisture", val: `${t.moistureContent}%`, pass: t.moisturePass },
                              { label: "Pesticides", val: `${t.pesticideLevel} ppm`, pass: t.pesticidePass },
                              { label: "Heavy Metals", val: `${t.heavyMetals} ppm`, pass: t.heavyMetalsPass },
                              { label: "Microbial", val: `${t.microbialCount} CFU/g`, pass: t.microbialPass },
                              { label: "Aflatoxin", val: `${t.aflatoxinLevel} ppb`, pass: t.aflatoxinPass },
                              { label: "DNA Match", val: t.dnaBarcodeMatch ? "Confirmed" : "Failed", pass: t.dnaBarcodeMatch },
                            ].map(r => (
                              <div key={r.label} className="flex justify-between p-2 rounded bg-muted/50">
                                <span className="text-muted-foreground">{r.label}</span>
                                <span className={`font-medium ${r.pass ? "text-primary" : "text-destructive"}`}>{r.val} {r.pass ? "✓" : "✗"}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )) : <p className="text-muted-foreground text-sm">Quality tests pending for this batch.</p>}
                    </div>
                  )}

                  {activeTab === "processing" && (
                    <div className="space-y-4">
                      <h3 className="font-display text-lg font-semibold text-foreground">Processing Chain</h3>
                      {scannedBatch.processingSteps.length > 0 ? (
                        <div className="space-y-3">
                          {scannedBatch.processingSteps.map((s, i) => (
                            <div key={s.id} className="flex gap-4 p-3 rounded-lg bg-muted/50">
                              <div className="text-center">
                                <div className="w-8 h-8 rounded-full gradient-leaf flex items-center justify-center text-primary-foreground text-sm font-bold">{i + 1}</div>
                              </div>
                              <div className="flex-1">
                                <p className="font-medium text-foreground capitalize">{s.stepType}</p>
                                <p className="text-xs text-muted-foreground">{s.facilityName}</p>
                                <p className="text-xs text-muted-foreground mt-1">{s.temperature}°C • {s.inputWeight}kg → {s.outputWeight}kg</p>
                                <p className="text-xs text-muted-foreground italic mt-1">{s.notes}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : <p className="text-muted-foreground text-sm">Processing not yet started.</p>}
                    </div>
                  )}

                  {activeTab === "sustainability" && (
                    <div className="space-y-4">
                      <h3 className="font-display text-lg font-semibold text-foreground">Sustainability & Fair Trade</h3>
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div className="p-4 rounded-lg bg-muted/50 text-center">
                          <p className="text-4xl font-display font-bold text-primary">{scannedBatch.sustainabilityScore}%</p>
                          <p className="text-sm text-muted-foreground mt-1">Sustainability Score</p>
                        </div>
                        <div className="p-4 rounded-lg bg-muted/50 text-center">
                          <p className="text-4xl font-display font-bold text-foreground">{scannedBatch.fairTradeVerified ? "✅" : "⏳"}</p>
                          <p className="text-sm text-muted-foreground mt-1">Fair Trade {scannedBatch.fairTradeVerified ? "Verified" : "Pending"}</p>
                        </div>
                      </div>
                      <div className="p-4 rounded-lg border border-primary/20 bg-primary/5">
                        <div className="flex items-center gap-2 mb-2">
                          <Shield className="w-5 h-5 text-primary" />
                          <span className="font-medium text-foreground">NMPB Compliance</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          This batch meets National Medicinal Plants Board guidelines for sustainable harvesting,
                          including geo-fence verification, seasonal compliance, and species conservation limits.
                        </p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Blockchain proof */}
              <Card className="shadow-card">
                <CardHeader><CardTitle className="font-display text-sm">Blockchain Proof</CardTitle></CardHeader>
                <CardContent className="space-y-2 text-xs font-mono text-muted-foreground">
                  <p>Network: Hyperledger Fabric v2.5 (Permissioned)</p>
                  <p>Channel: ayurveda-traceability</p>
                  <p>Chaincode: vanasetu-provenance v1.2.0</p>
                  <p>Batch Created: {new Date(scannedBatch.createdAt).toISOString()}</p>
                  <p>Last Updated: {new Date(scannedBatch.updatedAt).toISOString()}</p>
                  <p>Total Events: {scannedBatch.collectionEvents.length + scannedBatch.qualityTests.length + scannedBatch.processingSteps.length}</p>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {query && !scannedBatch && !identifiedHerb && !showQuiz && (
          <Card className="shadow-card text-center p-10">
            <Package className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-foreground font-medium">No product found</p>
            <p className="text-sm text-muted-foreground">Try one of the sample QR codes or herb names above</p>
          </Card>
        )}

        {/* Sample QR Codes for Testing */}
        <Card className="shadow-card mt-8">
          <CardHeader>
            <CardTitle className="font-display text-lg flex items-center gap-2">
              <QrCode className="w-5 h-5 text-primary" /> Sample QR Codes for Testing
            </CardTitle>
            <p className="text-sm text-muted-foreground">Scan these QR codes with the camera scanner to test the verification flow</p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {batches.map(b => (
                <button key={b.id} onClick={() => quickScan(b)}
                  className="flex flex-col items-center p-4 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-colors cursor-pointer">
                  <div className="bg-white p-2 rounded-lg mb-2">
                    <QRCodeSVG value={b.qrCode} size={80} />
                  </div>
                  <p className="text-xs font-medium text-foreground text-center">{b.commonName}</p>
                  <p className="text-xs text-muted-foreground font-mono">{b.qrCode}</p>
                  <Badge className="mt-1 text-[10px] bg-primary/10 text-primary capitalize">{b.status}</Badge>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
