import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AlertTriangle, CloudRain, Droplets, Flame, CloudSun, Wind, ChevronDown, ChevronUp, Shield, CheckCircle2, Bell } from "lucide-react";
import { farmerAlerts, FarmerAlert } from "@/data/alertsData";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const typeIcons: Record<string, any> = {
  "heavy-rain": CloudRain,
  flood: Droplets,
  fire: Flame,
  drought: CloudSun,
  cyclone: Wind,
  frost: CloudSun,
  hailstorm: CloudRain,
};

const severityColors: Record<string, string> = {
  critical: "bg-destructive text-destructive-foreground",
  warning: "bg-saffron text-primary-foreground",
  info: "bg-primary text-primary-foreground",
};

function AlertCard({ alert }: { alert: FarmerAlert }) {
  const [expanded, setExpanded] = useState(alert.isActive);
  const Icon = typeIcons[alert.type] || AlertTriangle;

  return (
    <Card className={`shadow-card overflow-hidden ${alert.isActive ? "border-l-4" : "opacity-70"} ${
      alert.severity === "critical" ? "border-l-destructive" : alert.severity === "warning" ? "border-l-saffron" : "border-l-primary"
    }`}>
      <div className="p-4 cursor-pointer" onClick={() => setExpanded(!expanded)}>
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${severityColors[alert.severity]}`}>
              <Icon className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-display text-base font-semibold text-foreground">{alert.title}</h3>
                {alert.isActive && <span className="relative flex h-2 w-2"><span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-destructive opacity-75"></span><span className="relative inline-flex rounded-full h-2 w-2 bg-destructive"></span></span>}
              </div>
              <p className="text-sm text-muted-foreground">{alert.description}</p>
              <div className="flex flex-wrap gap-1 mt-2">
                <Badge className={severityColors[alert.severity]} >{alert.severity}</Badge>
                {alert.affectedRegions.map(r => <Badge key={r} variant="outline" className="text-xs">{r}</Badge>)}
              </div>
            </div>
          </div>
          {expanded ? <ChevronUp className="w-5 h-5 text-muted-foreground" /> : <ChevronDown className="w-5 h-5 text-muted-foreground" />}
        </div>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}>
            <CardContent className="p-4 pt-0 space-y-4">
              {/* Step-by-step guidance */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Shield className="w-4 h-4 text-primary" />
                  <h4 className="font-medium text-foreground">Step-by-Step Emergency Guidance</h4>
                </div>
                <div className="space-y-2">
                  {alert.guidance.map(g => (
                    <div key={g.step} className="flex gap-3 p-3 rounded-lg bg-muted/50">
                      <div className="w-7 h-7 rounded-full gradient-leaf flex items-center justify-center text-primary-foreground text-xs font-bold shrink-0">
                        {g.step}
                      </div>
                      <div>
                        <p className="font-medium text-foreground text-sm">{g.action}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{g.detail}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Crop protection */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                  <h4 className="font-medium text-foreground">Crop Protection Tips</h4>
                </div>
                <ul className="space-y-1.5">
                  {alert.cropProtection.map((tip, i) => (
                    <li key={i} className="text-sm text-muted-foreground flex gap-2">
                      <span className="text-primary">🌿</span> {tip}
                    </li>
                  ))}
                </ul>
              </div>

              <p className="text-xs text-muted-foreground">
                Alert issued: {new Date(alert.timestamp).toLocaleString()} • {alert.isActive ? "⚡ Active" : "✓ Resolved"}
              </p>
            </CardContent>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}

export default function AlertsPage() {
  const [showAll, setShowAll] = useState(false);
  const displayed = showAll ? farmerAlerts : farmerAlerts.filter(a => a.isActive);

  return (
    <div className="min-h-screen bg-background pt-20 pb-12">
      <div className="container mx-auto px-4 max-w-4xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
          <div className="w-16 h-16 rounded-full bg-destructive/10 mx-auto flex items-center justify-center mb-4">
            <Bell className="w-8 h-8 text-destructive" />
          </div>
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">Farmer Alerts</h1>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Real-time natural hazard alerts with step-by-step guidance to protect your herbs and crops
          </p>
        </motion.div>

        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-muted-foreground">
            {farmerAlerts.filter(a => a.isActive).length} active alerts
          </p>
          <button onClick={() => setShowAll(!showAll)}
            className="text-sm text-primary hover:underline">
            {showAll ? "Show active only" : "Show all alerts"}
          </button>
        </div>

        <div className="space-y-4">
          {displayed.map(alert => <AlertCard key={alert.id} alert={alert} />)}
        </div>

        {displayed.length === 0 && (
          <Card className="text-center p-10 shadow-card">
            <CheckCircle2 className="w-12 h-12 text-primary mx-auto mb-4" />
            <p className="text-foreground font-medium">All clear!</p>
            <p className="text-sm text-muted-foreground">No active alerts at this time</p>
          </Card>
        )}
      </div>
    </div>
  );
}
