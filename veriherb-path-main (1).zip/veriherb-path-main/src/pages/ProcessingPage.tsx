import { motion } from "framer-motion";
import { ArrowDown, Thermometer, Droplets, Weight, Clock } from "lucide-react";
import { batches } from "@/data/mockData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const stepIcons: Record<string, string> = {
  drying: "☀️", grinding: "⚙️", extraction: "🧪", blending: "🔄", packaging: "📦",
};

export default function ProcessingPage() {
  const allBatchesWithSteps = batches.filter(b => b.processingSteps.length > 0);

  return (
    <div className="min-h-screen bg-background pt-20 pb-12">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">Processing Steps</h1>
          <p className="text-muted-foreground mb-8">Chain-of-custody processing events tracked on the ledger</p>
        </motion.div>

        {allBatchesWithSteps.map(batch => (
          <div key={batch.id} className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <h2 className="font-display text-xl font-semibold text-foreground">{batch.commonName}</h2>
              <Badge variant="outline" className="font-mono text-xs">{batch.id}</Badge>
            </div>

            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-6 top-0 bottom-0 w-px bg-border hidden md:block" />

              <div className="space-y-6">
                {batch.processingSteps.map((step, i) => (
                  <motion.div key={step.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.15 }}
                    className="md:ml-14 relative">
                    {/* Timeline dot */}
                    <div className="absolute -left-[3.25rem] top-6 w-4 h-4 rounded-full gradient-leaf border-2 border-background hidden md:block" />

                    <Card className="shadow-card">
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <span className="text-2xl">{stepIcons[step.stepType]}</span>
                            <div>
                              <CardTitle className="font-display capitalize">{step.stepType}</CardTitle>
                              <p className="text-sm text-muted-foreground">{step.facilityName}</p>
                            </div>
                          </div>
                          <Badge variant="outline" className="text-xs font-mono">Step {i + 1}</Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                          <div className="flex items-center gap-2">
                            <Thermometer className="w-4 h-4 text-turmeric" />
                            <div>
                              <p className="text-xs text-muted-foreground">Temperature</p>
                              <p className="text-sm font-medium text-foreground">{step.temperature}°C</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Droplets className="w-4 h-4 text-turmeric" />
                            <div>
                              <p className="text-xs text-muted-foreground">Humidity</p>
                              <p className="text-sm font-medium text-foreground">{step.humidity}%</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Weight className="w-4 h-4 text-primary" />
                            <div>
                              <p className="text-xs text-muted-foreground">In → Out</p>
                              <p className="text-sm font-medium text-foreground">{step.inputWeight}kg → {step.outputWeight}kg</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4 text-primary" />
                            <div>
                              <p className="text-xs text-muted-foreground">Duration</p>
                              <p className="text-sm font-medium text-foreground">
                                {Math.round((new Date(step.endTime).getTime() - new Date(step.startTime).getTime()) / 3600000)}h
                              </p>
                            </div>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground italic">{step.notes}</p>
                        <div className="mt-3 text-xs text-muted-foreground font-mono bg-muted/50 p-2 rounded">
                          TX: {step.txHash.slice(0, 30)}...
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
