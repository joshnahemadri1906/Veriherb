import { motion } from "framer-motion";
import { Package, Activity, Network, Leaf, Users, FlaskConical, QrCode, TrendingUp } from "lucide-react";
import { dashboardMetrics, monthlyData, speciesDistribution, batches, networkNodes } from "@/data/mockData";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, CartesianGrid } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";

const statCards = [
  { label: "Total Batches", value: dashboardMetrics.totalBatches, icon: Package, color: "text-primary" },
  { label: "Active Batches", value: dashboardMetrics.activeBatches, icon: Activity, color: "text-herb-green-light" },
  { label: "Transactions", value: dashboardMetrics.totalTransactions.toLocaleString(), icon: TrendingUp, color: "text-turmeric" },
  { label: "Network Nodes", value: dashboardMetrics.networkNodes, icon: Network, color: "text-saffron" },
  { label: "Sustainability Score", value: `${dashboardMetrics.avgSustainabilityScore}%`, icon: Leaf, color: "text-primary" },
  { label: "Quality Pass Rate", value: `${dashboardMetrics.qualityPassRate}%`, icon: FlaskConical, color: "text-herb-green-light" },
  { label: "Species Tracked", value: dashboardMetrics.speciesTracked, icon: Leaf, color: "text-turmeric" },
  { label: "Consumer Scans", value: dashboardMetrics.consumerScans.toLocaleString(), icon: QrCode, color: "text-saffron" },
];

const statusColors: Record<string, string> = {
  harvested: "bg-herb-green-light/20 text-herb-green-light",
  testing: "bg-turmeric/20 text-turmeric",
  processing: "bg-saffron/20 text-saffron",
  formulated: "bg-primary/20 text-primary",
  dispatched: "bg-herb-green-light/20 text-herb-green-light",
  retail: "bg-turmeric/20 text-earth",
};

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-background pt-20 pb-12">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">Network Dashboard</h1>
          <p className="text-muted-foreground mb-8">Real-time overview of the VanaSetu blockchain network</p>
        </motion.div>

        {/* Stat cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {statCards.map((s, i) => (
            <motion.div key={s.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className="shadow-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <s.icon className={`w-8 h-8 ${s.color}`} />
                    <div>
                      <p className="text-2xl font-bold text-foreground">{s.value}</p>
                      <p className="text-xs text-muted-foreground">{s.label}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Charts */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <Card className="lg:col-span-2 shadow-card">
            <CardHeader><CardTitle className="font-display">Monthly Activity</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(40,15%,85%)" />
                  <XAxis dataKey="month" tick={{ fill: "hsl(150,10%,45%)", fontSize: 12 }} />
                  <YAxis tick={{ fill: "hsl(150,10%,45%)", fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="batches" fill="hsl(145,45%,28%)" radius={[4, 4, 0, 0]} name="Batches" />
                  <Bar dataKey="transactions" fill="hsl(38,55%,55%)" radius={[4, 4, 0, 0]} name="Transactions" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="shadow-card">
            <CardHeader><CardTitle className="font-display">Species Distribution</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={speciesDistribution} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3}>
                    {speciesDistribution.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex flex-wrap gap-2 mt-2">
                {speciesDistribution.map(s => (
                  <div key={s.name} className="flex items-center gap-1 text-xs text-muted-foreground">
                    <div className="w-2 h-2 rounded-full" style={{ background: s.fill }} />
                    {s.name}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Consumer scans line */}
        <Card className="shadow-card mb-8">
          <CardHeader><CardTitle className="font-display">Consumer Scan Trends</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(40,15%,85%)" />
                <XAxis dataKey="month" tick={{ fill: "hsl(150,10%,45%)", fontSize: 12 }} />
                <YAxis tick={{ fill: "hsl(150,10%,45%)", fontSize: 12 }} />
                <Tooltip />
                <Line type="monotone" dataKey="scans" stroke="hsl(28,60%,50%)" strokeWidth={2} dot={{ fill: "hsl(28,60%,50%)" }} name="Consumer Scans" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Recent batches */}
        <Card className="shadow-card mb-8">
          <CardHeader><CardTitle className="font-display">Recent Batches</CardTitle></CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-left">
                    <th className="pb-3 text-muted-foreground font-medium">Batch ID</th>
                    <th className="pb-3 text-muted-foreground font-medium">Species</th>
                    <th className="pb-3 text-muted-foreground font-medium">Product</th>
                    <th className="pb-3 text-muted-foreground font-medium">Status</th>
                    <th className="pb-3 text-muted-foreground font-medium">Sustainability</th>
                    <th className="pb-3 text-muted-foreground font-medium">Fair Trade</th>
                  </tr>
                </thead>
                <tbody>
                  {batches.map(b => (
                    <tr key={b.id} className="border-b border-border/50">
                      <td className="py-3 font-mono text-xs text-foreground">{b.id}</td>
                      <td className="py-3"><span className="italic text-muted-foreground">{b.species}</span></td>
                      <td className="py-3 text-foreground">{b.productName}</td>
                      <td className="py-3"><Badge className={statusColors[b.status]}>{b.status}</Badge></td>
                      <td className="py-3 text-foreground">{b.sustainabilityScore}%</td>
                      <td className="py-3">{b.fairTradeVerified ? "✅" : "⏳"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Network nodes */}
        <Card className="shadow-card">
          <CardHeader><CardTitle className="font-display">Network Nodes</CardTitle></CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {networkNodes.map(node => (
                <div key={node.id} className="p-4 rounded-lg bg-muted/50 border border-border">
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`w-2 h-2 rounded-full ${node.isActive ? "bg-primary animate-pulse-glow" : "bg-destructive"}`} />
                    <span className="text-xs font-medium text-muted-foreground uppercase">{node.type}</span>
                  </div>
                  <p className="font-semibold text-foreground text-sm mb-1">{node.name}</p>
                  <p className="text-xs text-muted-foreground">{node.location}</p>
                  <p className="text-xs text-muted-foreground mt-1">{node.transactionCount} transactions</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
