import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Shield, MapPin, Leaf, QrCode, BarChart3, Cpu } from "lucide-react";
import { Button } from "@/components/ui/button";

const features = [
  { icon: Shield, title: "Immutable Ledger", desc: "Every transaction permanently recorded on a permissioned Hyperledger Fabric network" },
  { icon: MapPin, title: "Geo-Tagged Harvest", desc: "GPS-enabled capture of collection coordinates with geo-fencing validation" },
  { icon: Leaf, title: "Sustainability Enforced", desc: "Smart contracts validate NMPB guidelines, seasonal restrictions & conservation limits" },
  { icon: QrCode, title: "Consumer Transparency", desc: "Scan any QR code to view complete FHIR-style provenance bundle" },
  { icon: BarChart3, title: "Real-Time Analytics", desc: "RESTful dashboards for harvest volumes, QA metrics & environmental impact" },
  { icon: Cpu, title: "Offline-First Design", desc: "SMS-over-blockchain gateway for rural connectivity with offline data sync" },
];

const stageLabels = ["Harvest", "Lab Testing", "Processing", "Formulation", "Retail", "Consumer"];

export default function LandingPage() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative gradient-hero min-h-screen flex items-center overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.15'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")" }} />
        <div className="container mx-auto px-4 pt-24 pb-16 relative z-10">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}
            className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-turmeric/30 bg-turmeric/10 mb-8">
              <span className="w-2 h-2 rounded-full bg-turmeric animate-pulse-glow" />
              <span className="text-turmeric text-sm font-medium">Blockchain-Powered Traceability</span>
            </div>
            <h1 className="font-display text-5xl md:text-7xl font-bold text-cream leading-tight mb-6">
              From <span className="text-gradient-gold">Sacred Soil</span> to Trusted Shelf
            </h1>
            <p className="text-cream/70 text-lg md:text-xl max-w-2xl mb-10 font-body leading-relaxed">
              VanaSetu bridges ancient Ayurvedic wisdom with modern blockchain technology—delivering
              immutable provenance, geo-tagged transparency and smart-contract compliance for every herb.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/dashboard">
                <Button className="gradient-gold text-forest font-semibold px-8 py-6 text-base rounded-lg hover:opacity-90 transition-opacity">
                  Explore Dashboard <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link to="/consumer">
                <Button variant="outline" className="border-cream/30 text-cream hover:bg-cream/10 px-8 py-6 text-base rounded-lg">
                  Scan a Product
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Supply chain visual */}
        <div className="absolute bottom-0 left-0 right-0 py-8 bg-gradient-to-t from-background/20 to-transparent">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between max-w-3xl mx-auto">
              {stageLabels.map((label, i) => (
                <div key={label} className="flex items-center">
                  <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.5 + i * 0.15 }}
                    className="flex flex-col items-center gap-1">
                    <div className="w-3 h-3 rounded-full bg-turmeric/80" />
                    <span className="text-cream/50 text-xs hidden sm:block">{label}</span>
                  </motion.div>
                  {i < stageLabels.length - 1 && <div className="w-8 sm:w-16 h-px bg-cream/20 mx-1" />}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="text-center mb-16">
            <h2 className="font-display text-4xl font-bold text-foreground mb-4">End-to-End Traceability</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
              Six pillars of trust powering transparent, sustainable Ayurvedic supply chains
            </p>
          </motion.div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <motion.div key={f.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                className="group p-8 rounded-xl bg-card shadow-card hover:shadow-elevated transition-shadow border border-border">
                <div className="w-12 h-12 rounded-lg gradient-leaf flex items-center justify-center mb-5">
                  <f.icon className="w-6 h-6 text-primary-foreground" />
                </div>
                <h3 className="font-display text-xl font-semibold text-foreground mb-2">{f.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-24 bg-muted/50">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-4xl font-bold text-foreground text-center mb-16">How VanaSetu Works</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: "01", title: "Geo-Tagged Harvest", desc: "Collectors record GPS coordinates, species ID and environmental conditions via mobile DApp" },
              { step: "02", title: "Lab Certification", desc: "DNA barcoding, pesticide analysis and moisture tests logged immutably on-chain" },
              { step: "03", title: "Smart Processing", desc: "Each drying, grinding and blending step recorded with temperature and weight data" },
              { step: "04", title: "Consumer Verification", desc: "Scan QR code to view full provenance bundle with interactive maps and certificates" },
            ].map((item, i) => (
              <motion.div key={item.step} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.15 }}
                className="text-center">
                <div className="text-6xl font-display font-bold text-primary/10 mb-4">{item.step}</div>
                <h3 className="font-display text-lg font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 gradient-hero">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-display text-4xl font-bold text-cream mb-6">Ready to Transform Your Supply Chain?</h2>
          <p className="text-cream/70 max-w-xl mx-auto mb-10 text-lg">
            Join the network of cooperatives, labs and manufacturers building trust through transparency.
          </p>
          <Link to="/dashboard">
            <Button className="gradient-gold text-forest font-semibold px-10 py-6 text-lg rounded-lg hover:opacity-90">
              Get Started <ArrowRight className="ml-2" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-forest py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Leaf className="w-5 h-5 text-turmeric" />
            <span className="font-display text-cream font-bold">VanaSetu</span>
          </div>
          <p className="text-cream/40 text-sm">Blockchain-Based Botanical Traceability for Ayurvedic Herbs</p>
          <p className="text-cream/30 text-xs mt-2">Proof-of-Concept • Hyperledger Fabric Network</p>
        </div>
      </footer>
    </div>
  );
}
