import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Navbar from "@/components/Navbar";
import LandingPage from "@/pages/LandingPage";
import DashboardPage from "@/pages/DashboardPage";
import CollectionPage from "@/pages/CollectionPage";
import QualityPage from "@/pages/QualityPage";
import ProcessingPage from "@/pages/ProcessingPage";
import ConsumerPortal from "@/pages/ConsumerPortal";
import HerbDirectoryPage from "@/pages/HerbDirectoryPage";
import HealthGuidancePage from "@/pages/HealthGuidancePage";
import AlertsPage from "@/pages/AlertsPage";
import FarmerUploadPage from "@/pages/FarmerUploadPage";
import LoginPage from "@/pages/LoginPage";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/collection" element={<CollectionPage />} />
          <Route path="/quality" element={<QualityPage />} />
          <Route path="/processing" element={<ProcessingPage />} />
          <Route path="/consumer" element={<ConsumerPortal />} />
          <Route path="/herbs" element={<HerbDirectoryPage />} />
          <Route path="/health" element={<HealthGuidancePage />} />
          <Route path="/alerts" element={<AlertsPage />} />
          <Route path="/farmer-upload" element={<FarmerUploadPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
